import cv2
import numpy as np
import math
import time

# 视频文件路径
input_video = 'MP41.mp4'
output_video = 'meter_processed_fixed.avi'

# 常量定义 
MIN_ANGLE = -135
MAX_ANGLE = 135
MIN_VALUE = 0
MAX_VALUE = 6
ANGLE_OFFSET = 0  # 角度偏移量，可调整以修正指针方向

# 圆位置平滑滤波器
class CircleSmoother:
    def __init__(self, buffer_size=5):
        self.buffer_size = buffer_size
        self.center_buffer = []
        self.radius_buffer = []
        self.last_detected = time.time()
    
    def update(self, center, radius):
        if center is not None:
            self.center_buffer.append(center)
            self.radius_buffer.append(radius)
            self.last_detected = time.time()
            
            # 保持缓冲区大小
            if len(self.center_buffer) > self.buffer_size:
                self.center_buffer.pop(0)
                self.radius_buffer.pop(0)
                
        # 超过1秒未检测到，清空缓冲区
        if time.time() - self.last_detected > 1.0:
            self.center_buffer = []
            self.radius_buffer = []
    
    def get_smooth_circle(self):
        if not self.center_buffer:
            return None, None
            
        avg_center = np.mean(self.center_buffer, axis=0)
        avg_radius = np.mean(self.radius_buffer)
        return avg_center.astype(int), int(avg_radius)

try:
    # 打开视频文件
    cap = cv2.VideoCapture(input_video)
    if not cap.isOpened():
        print("无法打开视频文件")
        exit()

    # 获取视频参数
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    print(f"视频信息: {width}x{height}@{fps}fps, 总帧数: {total_frames}")

    # 尝试多种编解码器
    codecs = ['MJPG', 'XVID', 'DIVX']
    out = None
    for codec in codecs:
        try:
            fourcc = cv2.VideoWriter_fourcc(*codec)
            out = cv2.VideoWriter(output_video, fourcc, fps, (width, height))
            if out.isOpened():
                print(f"成功使用编解码器: {codec}")
                break
            else:
                out = None
        except:
            print(f"编解码器 {codec} 尝试失败")
    
    if out is None:
        print("错误: 无法找到可用的视频编解码器!")
        exit()

    # 状态变量
    last_value = MIN_VALUE
    font = cv2.FONT_HERSHEY_SIMPLEX
    count = 0
    circle_smoother = CircleSmoother(buffer_size=10)  # 更长的平滑窗口
    
    # 性能统计
    circle_detection_time = 0
    pointer_detection_time = 0
    start_time = time.time()

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
            
        count += 1
        if count % 50 == 0:
            print(f"处理进度: {count}/{total_frames} ({count/total_frames*100:.1f}%)")
        
        frame_org = frame.copy()

        try:
            # ====== 圆检测 ======
            t_circle_start = time.time()
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            blur = cv2.GaussianBlur(gray, (9, 9), 0)  # 更大的模糊核
            edges = cv2.Canny(blur, 30, 100)
            
            # 尝试使用平滑后的圆位置创建ROI
            smooth_center, smooth_radius = circle_smoother.get_smooth_circle()
            roi_x1, roi_y1, roi_x2, roi_y2 = 0, 0, width, height
            
            if smooth_center is not None and smooth_radius > 0:
                roi_size = int(smooth_radius * 2.5)
                roi_x1 = max(0, smooth_center[0] - roi_size)
                roi_y1 = max(0, smooth_center[1] - roi_size)
                roi_x2 = min(width, smooth_center[0] + roi_size)
                roi_y2 = min(height, smooth_center[1] + roi_size)
                roi = blur[roi_y1:roi_y2, roi_x1:roi_x2]
            else:
                roi = blur
            
            circle_detected = False
            center_x, center_y, radius = None, None, None
            
            circles = cv2.HoughCircles(
                roi,
                cv2.HOUGH_GRADIENT,
                dp=1.2,  # 增加dp值提高精度
                minDist=100,
                param1=50,
                param2=30,  # 提高检测置信度
                minRadius=80,
                maxRadius=200
            )
            
            if circles is not None:
                circles = np.uint16(np.around(circles))
                if circles.shape[1] > 0:
                    # 找到最佳圆（离平滑位置最近的）
                    best_circle = None
                    min_dist = float('inf')
                    
                    for circle in circles[0, :]:
                        cx, cy, cr = circle
                        # 转换到原始坐标
                        if smooth_center is not None:
                            cx += roi_x1
                            cy += roi_y1
                        
                        dist = math.sqrt((cx - width/2)**2 + (cy - height/2)**2)
                        
                        if dist < min_dist:
                            min_dist = dist
                            best_circle = (cx, cy, cr)
                    
                    if best_circle:
                        center_x, center_y, radius = best_circle
                        circle_detected = True
                        # 更新平滑器
                        circle_smoother.update(np.array([center_x, center_y]), radius)
            
            t_circle_end = time.time()
            circle_detection_time += t_circle_end - t_circle_start
            
            # 使用平滑后的圆位置
            smooth_center, smooth_radius = circle_smoother.get_smooth_circle()
            if smooth_center is not None:
                center_x, center_y = smooth_center
                radius = smooth_radius
                circle_detected = True
            
            if circle_detected:
                # 绘制圆心和表盘
                cv2.circle(frame, (center_x, center_y), 5, (0, 0, 255), -1)
                cv2.circle(frame, (center_x, center_y), radius, (0, 255, 0), 2)
                
                # ====== 指针检测 ======
                t_pointer_start = time.time()
                # 创建ROI区域
                roi_mask = np.zeros_like(gray)
                cv2.circle(roi_mask, (center_x, center_y), int(radius*0.85), 255, -1)
                roi_edges = cv2.bitwise_and(edges, roi_mask)
                
                # 霍夫线变换检测指针
                lines = cv2.HoughLinesP(
                    roi_edges,
                    rho=1,
                    theta=np.pi/180,
                    threshold=40,  # 提高阈值减少噪声
                    minLineLength=radius*0.4,
                    maxLineGap=5
                )
                
                if lines is not None:
                    pointer_lines = []
                    
                    for line in lines:
                        x1, y1, x2, y2 = line[0]
                        # 计算线中点
                        mid_x = (x1 + x2) / 2
                        mid_y = (y1 + y2) / 2
                        # 计算到圆心的距离
                        dist = math.sqrt((mid_x - center_x)**2 + (mid_y - center_y)**2)
                        # 计算线长度
                        length = math.sqrt((x2-x1)**2 + (y2-y1)**2)
                        
                        # 过滤条件：距圆心不太远且长度合理
                        if dist < radius * 0.6 and length > radius*0.4 and length < radius*1.5:
                            # 计算方向向量
                            dx = x2 - x1
                            dy = y2 - y1
                            
                            # 确保方向从圆心向外
                            angle_to_center1 = math.degrees(math.atan2(center_y - y1, x1 - center_x))
                            angle_to_center2 = math.degrees(math.atan2(center_y - y2, x2 - center_x))
                            angle_diff = abs(angle_to_center1 - angle_to_center2)
                            
                            if angle_diff > 150:  # 角度差接近180度表示通过圆心
                                pointer_lines.append((x1, y1, x2, y2))
                    
                    if pointer_lines:
                        # 选择最长的线作为指针
                        longest_index = np.argmax([np.sqrt((l[2]-l[0])**2 + (l[3]-l[1])**2) 
                                                for l in pointer_lines])
                        x1, y1, x2, y2 = pointer_lines[longest_index]
                        
                        # 确定指针端点：选择离圆心更远的点
                        dist1 = math.sqrt((x1-center_x)**2 + (y1-center_y)**2)
                        dist2 = math.sqrt((x2-center_x)**2 + (y2-center_y)**2)
                        
                        if dist1 > dist2:
                            pointer_tip = (x1, y1)
                            pointer_base = (x2, y2)
                        else:
                            pointer_tip = (x2, y2)
                            pointer_base = (x1, y1)
                        
                        # 绘制指针
                        cv2.line(frame, pointer_base, pointer_tip, (0, 0, 255), 3)
                        
                        # ====== 角度计算 ======
                        dx = pointer_tip[0] - center_x
                        dy = center_y - pointer_tip[1]  # 反转y轴使向上为正
                        
                        # 计算角度（从正右方开始，逆时针为正）
                        angle_rad = math.atan2(dy, dx)
                        angle_deg = math.degrees(angle_rad)
                        
                        # 处理角度方向：从右开始，逆时针0°-360°
                        if angle_deg < 0:
                            angle_deg += 360
                            
                        # 应用角度偏移修正
                        angle_deg = (angle_deg + ANGLE_OFFSET) % 360
                        
                        # 转换为仪表角度（通常0点在顶部）
                        # 仪表0点在顶部（图像坐标系中为90度方向）
                        meter_angle = 90 - angle_deg
                        if meter_angle < 0:
                            meter_angle += 360
                            
                        # 将角度转换到MIN_ANGLE-MAX_ANGLE范围
                        if meter_angle > 180:
                            meter_angle -= 360
                            
                        # 限制角度在量程范围内
                        normalized_angle = max(MIN_ANGLE, min(MAX_ANGLE, meter_angle))
                        
                        # 计算值
                        total_range = MAX_ANGLE - MIN_ANGLE
                        value = MIN_VALUE + ((normalized_angle - MIN_ANGLE) / total_range) * (MAX_VALUE - MIN_VALUE)
                        
                        # 平滑处理
                        last_value = 0.8 * last_value + 0.2 * value
                        
                        # 显示读数
                        display_value = f"Reading: {last_value:.2f}"
                        cv2.rectangle(frame, (20, 20), (350, 100), (50, 50, 50), -1)
                        cv2.putText(frame, display_value, (50, 70), font, 1.2, (0, 255, 255), 2)
                        cv2.putText(frame, f"Min: {MIN_VALUE}", (50, 120), font, 0.7, (0, 200, 255), 2)
                        cv2.putText(frame, f"Max: {MAX_VALUE}", (200, 120), font, 0.7, (0, 200, 255), 2)
                        
                        # 绘制参考方向
                        end_x = int(center_x + radius * 0.8 * math.cos(angle_rad))
                        end_y = int(center_y - radius * 0.8 * math.sin(angle_rad))  # y轴向下需要取反
                        cv2.arrowedLine(frame, (center_x, center_y), (end_x, end_y), (255, 0, 0), 2)
                        
                        # 绘制量程指示
                        cv2.putText(frame, "ANGLE OFFSET: " + str(ANGLE_OFFSET), (width-300, 30), font, 0.7, (255, 255, 0), 2)
                        cv2.putText(frame, "Press ',' and '.' to adjust", (width-300, 60), font, 0.5, (200, 200, 255), 1)
                
                t_pointer_end = time.time()
                pointer_detection_time += t_pointer_end - t_pointer_start
        
        except Exception as e:
            print(f"第 {count} 帧处理错误: {str(e)}")
            frame = frame_org  # 出错时使用原始帧

        # 写入帧
        out.write(frame)

        # 显示实时结果
        cv2.imshow('Meter Reading', frame)
        
        # 键盘控制：调整角度偏移
        key = cv2.waitKey(1)
        if key == ord('q') or key == 27:  # ESC或Q退出
            break
        elif key == ord('.') or key == ord('>'):  # 增大角度偏移
            ANGLE_OFFSET = (ANGLE_OFFSET + 5) % 360
            print(f"角度偏移: {ANGLE_OFFSET}°")
        elif key == ord(',') or key == ord('<'):  # 减小角度偏移
            ANGLE_OFFSET = (ANGLE_OFFSET - 5) % 360
            print(f"角度偏移: {ANGLE_OFFSET}°")

except Exception as e:
    print(f"处理失败: {str(e)}")
finally:
    # 性能统计
    total_time = time.time() - start_time
    avg_circle_time = circle_detection_time / count * 1000 if count > 0 else 0
    avg_pointer_time = pointer_detection_time / count * 1000 if count > 0 else 0
    
    print(f"\n处理总结:")
    print(f"总帧数: {count}, 总时间: {total_time:.2f}s")
    print(f"平均帧率: {count/total_time:.2f} FPS")
    print(f"平均圆检测时间: {avg_circle_time:.2f} ms/帧")
    print(f"平均指针检测时间: {avg_pointer_time:.2f} ms/帧")
    
    # 释放资源
    if 'cap' in locals() and cap.isOpened():
        cap.release()
    if 'out' in locals() and out.isOpened():
        out.release()
    cv2.destroyAllWindows()
    print(f"视频处理完成，结果保存至: {output_video}")