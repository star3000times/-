# meter_detector.py
#使用opencv来识别仪表
import cv2
import numpy as np
import math
import logging
import time

# 圆位置平滑滤波器
class CircleSmoother:
    def __init__(self, buffer_size=5):
        self.buffer_size = buffer_size
        self.center_buffer = []
        self.radius_buffer = []
        self.last_detected = time.time()
    
    def update(self, center, radius):
        if center is not None:
            self.center_buffer.append(center)
            self.radius_buffer.append(radius)
            self.last_detected = time.time()
            
            # 保持缓冲区大小
            if len(self.center_buffer) > self.buffer_size:
                self.center_buffer.pop(0)
                self.radius_buffer.pop(0)
                
        # 超过1秒未检测到，清空缓冲区
        if time.time() - self.last_detected > 1.0:
            self.center_buffer = []
            self.radius_buffer = []
    
    def get_smooth_circle(self):
        if not self.center_buffer:
            return None, None
            
        avg_center = np.mean(self.center_buffer, axis=0)
        avg_radius = np.mean(self.radius_buffer)
        return avg_center.astype(int), int(avg_radius)

# 仪表检测核心函数
def detect_meter(frame, meter_params, circle_smoother, last_value):
    min_angle = meter_params["min_angle"]
    max_angle = meter_params["max_angle"]
    min_value = meter_params["min_value"]
    max_value = meter_params["max_value"]
    angle_offset = meter_params.get("angle_offset", 0)
    manual_angle = meter_params.get("manual_angle")
    
    # 预处理
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (9, 9), 0)
    edges = cv2.Canny(blur, 30, 100)
    
    reading = last_value
    height, width = gray.shape[:2]
    
    # 获取平滑后的圆位置，用于创建ROI
    smooth_center, smooth_radius = circle_smoother.get_smooth_circle()
    roi_x1, roi_y1, roi_x2, roi_y2 = 0, 0, width, height
    
    if smooth_center is not None and smooth_radius > 0:
        roi_size = int(smooth_radius * 2.5)
        roi_x1 = max(0, smooth_center[0] - roi_size)
        roi_y1 = max(0, smooth_center[1] - roi_size)
        roi_x2 = min(width, smooth_center[0] + roi_size)
        roi_y2 = min(height, smooth_center[1] + roi_size)
        roi = blur[roi_y1:roi_y2, roi_x1:roi_x2]
    else:
        roi = blur
    
    # 圆检测
    circles = cv2.HoughCircles(
        roi,
        cv2.HOUGH_GRADIENT,
        dp=1.2,
        minDist=100,
        param1=50,
        param2=30,
        minRadius=80,
        maxRadius=200
    )
    
    circle_detected = False
    center_x, center_y, radius = None, None, None
    
    if circles is not None:
        circles = np.uint16(np.around(circles))
        if circles.shape[1] > 0:
            # 找到最佳圆（离中心最近的）
            best_circle = None
            min_dist = float('inf')
            
            for circle in circles[0, :]:
                cx, cy, cr = circle
                # 转换到原始坐标
                if smooth_center is not None:
                    cx += roi_x1
                    cy += roi_y1
                
                # 优先选择靠近图像中心的圆
                dist = math.sqrt((cx - width/2)**2 + (cy - height/2)** 2)
                
                if dist < min_dist:
                    min_dist = dist
                    best_circle = (cx, cy, cr)
            
            if best_circle:
                center_x, center_y, radius = best_circle
                circle_detected = True
                # 更新平滑器
                circle_smoother.update(np.array([center_x, center_y]), radius)
    
    # 使用平滑后的圆位置
    smooth_center, smooth_radius = circle_smoother.get_smooth_circle()
    if smooth_center is not None:
        center_x, center_y = smooth_center
        radius = smooth_radius
        circle_detected = True
    
    if circle_detected:
        # 绘制圆心和表盘
        cv2.circle(frame, (center_x, center_y), 5, (0, 0, 255), -1)
        cv2.circle(frame, (center_x, center_y), radius, (0, 255, 0), 2)
        
        mean_angle = None  # 最终使用的指针角度
        
        # 1. 尝试手动角度
        if manual_angle is not None:
            mean_angle = manual_angle
            logging.info(f"使用手动配置角度: {manual_angle}°")
        
        # 2. 直线检测
        else:
            # 创建ROI掩码，只在表盘内部检测指针
            roi_mask = np.zeros_like(gray)
            cv2.circle(roi_mask, (center_x, center_y), int(radius*0.85), 255, -1)
            roi_edges = cv2.bitwise_and(edges, roi_mask)
            
            # 霍夫线变换检测指针
            lines = cv2.HoughLinesP(
                roi_edges,
                rho=1,
                theta=np.pi/180,
                threshold=40,
                minLineLength=radius*0.4,
                maxLineGap=5
            )
            
            if lines is not None:
                pointer_lines = []
                
                for line in lines:
                    x1, y1, x2, y2 = line[0]
                    # 计算线中点到圆心的距离
                    mid_x = (x1 + x2) / 2
                    mid_y = (y1 + y2) / 2
                    dist = math.sqrt((mid_x - center_x)**2 + (mid_y - center_y)** 2)
                    # 计算线长度
                    length = math.sqrt((x2-x1)**2 + (y2-y1)** 2)
                    
                    # 过滤条件：距圆心不远且长度合理
                    if dist < radius * 0.6 and length > radius*0.4 and length < radius*1.5:
                        # 判断是否通过圆心（角度差接近180度）
                        angle_to_center1 = math.degrees(math.atan2(center_y - y1, x1 - center_x))
                        angle_to_center2 = math.degrees(math.atan2(center_y - y2, x2 - center_x))
                        angle_diff = abs(angle_to_center1 - angle_to_center2)
                        
                        if angle_diff > 150:  # 角度差足够大，认为通过圆心
                            pointer_lines.append((x1, y1, x2, y2))
                
                if pointer_lines:
                    # 选择最长的线作为指针
                    longest_index = np.argmax([np.sqrt((l[2]-l[0])**2 + (l[3]-l[1])** 2) 
                                            for l in pointer_lines])
                    x1, y1, x2, y2 = pointer_lines[longest_index]
                    
                    # 确定指针端点：离圆心更远的点为尖端
                    dist1 = math.sqrt((x1-center_x)**2 + (y1-center_y)** 2)
                    dist2 = math.sqrt((x2-center_x)**2 + (y2-center_y)** 2)
                    
                    if dist1 > dist2:
                        pointer_tip = (x1, y1)
                    else:
                        pointer_tip = (x2, y2)
                    
                    # 计算指针角度（修正坐标系）
                    dx = pointer_tip[0] - center_x
                    dy = center_y - pointer_tip[1]  # 反转y轴，使向上为正
                    
                    angle_rad = math.atan2(dy, dx)
                    angle_deg = math.degrees(angle_rad)
                    
                    # 标准化角度到0-360度
                    if angle_deg < 0:
                        angle_deg += 360
                    
                    # 应用角度偏移
                    angle_deg = (angle_deg + angle_offset) % 360
                    
                    # 转换为仪表角度（0点在顶部）
                    meter_angle = 90 - angle_deg
                    if meter_angle < 0:
                        meter_angle += 360
                    
                    # 转换到[-180, 180]范围
                    if meter_angle > 180:
                        meter_angle -= 360
                    
                    mean_angle = meter_angle
                    logging.debug(f"自动检测角度: {mean_angle:.1f}°")
                else:
                    logging.warning("未检测到有效指针线段")
                    return frame, reading
        
        # 计算读数
        if mean_angle is not None:
            # 限制角度在量程范围内
            normalized_angle = max(min_angle, min(max_angle, mean_angle))
            
            # 映射角度到数值
            total_range_angle = max_angle - min_angle
            total_range_value = max_value - min_value
            if total_range_angle != 0 and total_range_value != 0:
                value = min_value + ((normalized_angle - min_angle) / total_range_angle) * total_range_value
                # 平滑处理
                reading = 0.8 * last_value + 0.2 * value
                logging.debug(f"计算读数: {reading:.2f}")
            
            # 绘制指针箭头
            arrow_length = radius * 0.8
            end_x = int(center_x + arrow_length * math.cos(math.radians(90 - mean_angle)))
            end_y = int(center_y - arrow_length * math.sin(math.radians(90 - mean_angle)))
            cv2.arrowedLine(frame, (center_x, center_y), (end_x, end_y), (0, 0, 255), 3)
        
        # 显示读数
        if reading is not None:
            # 半透明背景
            overlay = frame.copy()
            cv2.rectangle(overlay, (20, 20), (350, 100), (50, 50, 50), -1)
            frame = cv2.addWeighted(overlay, 0.6, frame, 0.4, 0)
            cv2.putText(
                frame,
                f"Reading: {reading:.2f}",
                (50, 70),
                cv2.FONT_HERSHEY_SIMPLEX,
                1.2,
                (0, 255, 255),
                2
            )
            cv2.putText(frame, f"Min: {min_value}", (50, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 200, 255), 2)
            cv2.putText(frame, f"Max: {max_value}", (200, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 200, 255), 2)
    
    else:
        logging.debug("未检测到表盘圆圈")
    
    return frame, reading