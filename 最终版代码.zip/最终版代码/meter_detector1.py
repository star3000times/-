# meter_detector1.py
#使用模型来识别仪表
import cv2
import numpy as np
import math
import re
from ultralytics import YOLO
from modelscope.pipelines import pipeline
from modelscope.utils.constant import Tasks

class MeterDetector1:
    def __init__(self, model_path, set_start_value=0, set_end_value=6, temp1=20, temp2=15):
        # 初始化参数
        self.set_start_value = set_start_value
        self.set_end_value = set_end_value
        self.temp1 = temp1
        self.temp2 = temp2
        
        # 状态变量
        self.prev_keypoints_array = None
        self.prev_saved_boxes = None
        self.prev_start_value = set_start_value
        self.prev_end_value = set_end_value
        
        # 初始化模型
        self.yolo_model = YOLO(model_path)
        self.ocr_recognition = pipeline(Tasks.ocr_recognition, model='cv_convnextTiny_ocr-recognition-document_damo')
    
    def find_center_and_sort_keypoints(self, keypoints_array, img_height):
        if len(keypoints_array) != 4:
            return None

        transformed_keypoints = [(x, img_height - y) for x, y in keypoints_array]
        cx = sum(p[0] for p in transformed_keypoints) / 4
        cy = sum(p[1] for p in transformed_keypoints) / 4
        center_point = min(transformed_keypoints, key=lambda p: np.linalg.norm(np.array(p) - np.array([cx, cy])))
        remaining_points = [p for p in transformed_keypoints if p != center_point]

        if len(remaining_points) != 3:
            return None

        def angle_counter_clockwise(p):
            dx, dy = p[0] - center_point[0], p[1] - center_point[1]
            angle = math.degrees(math.atan2(dx, -dy))
            return (angle + 360) % 360

        sorted_points = sorted(remaining_points, key=angle_counter_clockwise)
        end_point, needle_point, start_point = sorted_points

        end_angle = angle_counter_clockwise(end_point)
        start_angle = angle_counter_clockwise(start_point)
        if (start_angle - end_angle) % 360 < 180:
            start_point, end_point = end_point, start_point

        def revert_y(p):
            return (p[0], img_height - p[1])

        return revert_y(center_point), revert_y(start_point), revert_y(needle_point), revert_y(end_point)
    
    def ocr_read_number(self, frame, box):
        try:
            l, t, r, b, conf, cls_id = map(int, box)
            if cls_id == 1:
                b -= self.temp2
                l += self.temp1
            if cls_id == 2:
                b -= self.temp2
                r -= self.temp1
            roi = frame[t:b, l:r]
            ocr_results = self.ocr_recognition(roi)
            text_list = ocr_results.get('text', [])
            numbers = [re.findall(r'\d+\.\d+|\d+', t) for t in text_list]
            numbers = [num for sublist in numbers for num in sublist]
            return float(numbers[0]) if numbers else None
        except Exception as e:
            print(f"OCR 失败: {e}")
            return None
    
    @staticmethod
    def transform_coordinates(point, img_height):
        return (point[0], img_height - point[1])
    
    @staticmethod
    def clockwise_angle(A, B, O):
        ax, ay = A[0] - O[0], A[1] - O[1]
        bx, by = B[0] - O[0], B[1] - O[1]
        angle_A = math.degrees(math.atan2(ay, ax))
        angle_B = math.degrees(math.atan2(by, bx))
        return (angle_A - angle_B) % 360
    
    def detect_meter(self, frame, meter_params=None, last_value=None):
        if meter_params is None:
            meter_params = {}
            
        # 使用last_value作为初始值，如果没有则使用默认值
        if last_value is None:
            last_value = self.set_start_value
            
        orig_h, orig_w = frame.shape[:2]
        frame_copy = frame.copy()
        
        # 模型预测
        results = self.yolo_model.predict(frame, imgsz=640, conf=0.5)
        result = results[0]
        
        # 处理检测框
        saved_boxes = []
        for detection in result.boxes.data.cpu().numpy():
            l, t, r, b, conf, cls_id = detection
            cls_id = int(cls_id)
            if cls_id in [1, 2]:
                saved_boxes.append([l, t, r, b, conf, cls_id])
            cv2.rectangle(frame_copy, (int(l), int(t)), (int(r), int(b)), (0, 0, 255), 2)
        
        # 使用上一帧的检测框如果当前帧检测不足
        if len(saved_boxes) < 2 and self.prev_saved_boxes is not None:
            saved_boxes = self.prev_saved_boxes.copy()
        self.prev_saved_boxes = saved_boxes.copy()
        
        # 读取起始值和结束值
        try:
            start_value = self.ocr_read_number(frame, saved_boxes[0]) if len(saved_boxes) > 0 else None
            if start_value is None:
                start_value = self.prev_start_value
        except:
            start_value = self.prev_start_value
        
        try:
            end_value = self.ocr_read_number(frame, saved_boxes[1]) if len(saved_boxes) > 1 else None
            if end_value is None:
                end_value = self.prev_end_value
        except:
            end_value = self.prev_end_value
        
        self.prev_start_value, self.prev_end_value = start_value, end_value
        
        # 处理关键点
        keypoints_array = []
        keypoints = result.keypoints.cpu().numpy().data if result.keypoints is not None else []
        for keypoint_set in keypoints:
            for keypoint in keypoint_set:
                x, y, conf = keypoint
                if conf > 0.5:
                    keypoints_array.append((x, y))
                    cv2.circle(frame_copy, (int(x), int(y)), 5, (0, 255, 0), -1)
        
        # 使用上一帧的关键点如果当前帧检测不足
        if len(keypoints_array) < 4 and self.prev_keypoints_array is not None:
            keypoints_array = self.prev_keypoints_array.copy()
        self.prev_keypoints_array = keypoints_array.copy()
        
        # 排序关键点并计算读数
        sorted_keypoints = self.find_center_and_sort_keypoints(keypoints_array, orig_h)
        if sorted_keypoints is None:
            return frame_copy, last_value
        
        center_point, start_point, needle_point, end_point = sorted_keypoints
        
        if len(keypoints_array) < 4:
            return frame_copy, last_value
        
        # 绘制关键点
        cv2.circle(frame_copy, (int(center_point[0]), int(center_point[1])), 5, (255, 255, 0), -1)
        cv2.circle(frame_copy, (int(start_point[0]), int(start_point[1])), 5, (255, 0, 255), -1)
        cv2.circle(frame_copy, (int(needle_point[0]), int(needle_point[1])), 5, (0, 255, 255), -1)
        cv2.circle(frame_copy, (int(end_point[0]), int(end_point[1])), 5, (255, 0, 0), -1)
        
        # 转换坐标并计算角度
        center_point_t = self.transform_coordinates(center_point, orig_h)
        needle_point_t = self.transform_coordinates(needle_point, orig_h)
        start_point_t = self.transform_coordinates(start_point, orig_h)
        end_point_t = self.transform_coordinates(end_point, orig_h)
        
        angle_total = self.clockwise_angle(start_point_t, end_point_t, center_point_t)
        angle_pointer = self.clockwise_angle(start_point_t, needle_point_t, center_point_t)
        
        # 计算当前读数
        try:
            current_reading = start_value + (angle_pointer / angle_total) * (end_value - start_value)
            # 简单平滑处理
            current_reading = 0.8 * last_value + 0.2 * current_reading
        except:
            current_reading = last_value
        
        # 显示读数
        reading_text = f"Reading: {current_reading:.2f}"
        cv2.putText(frame_copy, reading_text, (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)
        
        return frame_copy, current_reading