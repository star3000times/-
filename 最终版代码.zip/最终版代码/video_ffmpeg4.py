#视频输出路径:combined_output.mp4
import cv2
import numpy as np
import math
import json
import logging
import time
import os
from led_detector import LEDDetector
from meter_detector import CircleSmoother, detect_meter

def process_video(config_loader, mqtt_handler):
    logging.info("⌛ 等待MQTT发送配置参数...")
    while True:
        if config_loader.mqtt_updated:
            required_keys = ['hsv_ranges', 'video', 'detection', 'mqtt']
            if all(key in config_loader.config for key in required_keys):
                video_source = config_loader.get_video_source()
                is_valid_source = (
                    video_source.isdigit()  # 数字（摄像头索引）
                    or (isinstance(video_source, str) and os.path.isfile(video_source))  # 本地文件
                    or (isinstance(video_source, str) and video_source.startswith(('rtsp://', 'rtmp://', 'http://')))  # 网络流
                )
                
                if is_valid_source:
                    logging.info("✅ 已收到完整配置，开始检测流程")
                    break
        
        if not mqtt_handler.connected:
            mqtt_handler.reconnect()
        
        time.sleep(1)

    # ====================== 固定参数配置 ======================
    # 设备固定信息 - 这些信息将包含在每条消息中
    DEVICE_INFO = {
        "code": "205",                         # 固定代码
        "mac": "54:b2:03:fd:76:0d",             # MAC地址
        "device_no": "",     # 设备编号
        "device_type": "",                 # 设备类型
        "device_name": ""               # 设备名称
    }
    
    # 仪表参数 (从配置或固定值获取)
    METER_DEFAULT = {
        "min_value": 0,
        "max_value": 100,
        "center_x": None,
        "center_y": None,
        "radius": None
    }
    
    # 初始化配置参数
    color_ranges = config_loader.get_hsv_ranges()
    draw_colors = config_loader.get_draw_colors()
    min_area = config_loader.get_min_area()
    
    meter_params = config_loader.get_meter_params() or METER_DEFAULT
    last_meter_value = meter_params.get("min_value", 0)
    circle_smoother = CircleSmoother(buffer_size=10)
    
    source = config_loader.get_video_source()
    output_combined_path = config_loader.get_video_output_combined()

    # 创建检测器实例
    led_detector = LEDDetector(
        color_ranges=color_ranges,
        min_area=min_area,
        draw_colors=draw_colors
    )

    # 打开视频源
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        logging.error("❌ 无法打开视频源")
        return

    # 获取视频参数
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    logging.info(f"视频参数: 分辨率 {width}x{height}, 帧率 {fps}")

    # 初始化视频文件输出（保存绘制后的图像视频）
    codecs = ['MJPG', 'XVID', 'DIVX', 'mp4v']
    out_combined = None

    # 初始化最终输出文件
    for codec in codecs:
        try:
            fourcc = cv2.VideoWriter_fourcc(*codec)
            out_combined = cv2.VideoWriter(output_combined_path, fourcc, fps, (width, height))
            if out_combined.isOpened():
                logging.info(f"最终输出文件使用编解码器: {codec}")
                break
        except:
            continue
    if out_combined is None:
        logging.error("❌ 无法初始化最终视频输出文件")
        return

    # 创建显示窗口
    cv2.namedWindow('Video Processing', cv2.WINDOW_NORMAL)
    cv2.resizeWindow('Video Processing', width, height)

    # 视频处理统计
    frame_count = 0
    start_time = time.time()
    last_status_time = time.time()
    last_frame_time = time.time()
    dropped_frames = 0

    try:
        while True:
            # 检查配置更新
            if config_loader.check_for_updates():
                # 更新LED参数
                new_color_ranges = config_loader.get_hsv_ranges()
                new_draw_colors = config_loader.get_draw_colors()
                new_min_area = config_loader.get_min_area()
                led_detector.update_parameters(
                    color_ranges=new_color_ranges,
                    min_area=new_min_area,
                    draw_colors=new_draw_colors
                )

                # 更新仪表参数
                new_meter_params = config_loader.get_meter_params() or METER_DEFAULT
                meter_params = new_meter_params
                last_meter_value = meter_params.get("min_value", last_meter_value)

                # 更新MQTT配置
                mqtt_config = config_loader.get_mqtt_config()
                mqtt_handler.update_config(
                    broker=mqtt_config.get('broker'),
                    port=mqtt_config.get('port'),
                    topic=mqtt_handler.topic,
                    username=mqtt_config.get('user'),
                    password=mqtt_config.get('password'),
                    subscribe_topic=mqtt_handler.subscribe_topic
                )

                # 处理视频源变更
                new_source = config_loader.get_video_source()
                if new_source != source:
                    source = new_source
                    cap.release()
                    cap = cv2.VideoCapture(source)
                    if not cap.isOpened():
                        logging.error("❌ 无法打开新视频源")
                        break
                    # 更新视频参数
                    fps = int(cap.get(cv2.CAP_PROP_FPS))
                    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                    # 调整窗口大小
                    cv2.resizeWindow('Video Processing', width, height)

                # 处理最终输出路径变更
                new_output_combined = config_loader.get_video_output_combined()
                if new_output_combined != output_combined_path:
                    output_combined_path = new_output_combined
                    out_combined.release()
                    for codec in codecs:
                        try:
                            fourcc = cv2.VideoWriter_fourcc(*codec)
                            out_combined = cv2.VideoWriter(output_combined_path, fourcc, fps, (width, height))
                            if out_combined.isOpened():
                                logging.info(f"最终输出切换编解码器: {codec}")
                                break
                        except:
                            continue

            # 性能监控：防止帧率过高
            current_time = time.time()
            elapsed = current_time - last_frame_time
            expected_time = 1.0 / fps
            if elapsed < expected_time:
                sleep_time = expected_time - elapsed
                time.sleep(sleep_time * 0.9)  # 保留10%的余量
            
            last_frame_time = time.time()

            # 读取视频帧
            ret, frame = cap.read()
            if not ret:
                logging.warning("⚠️ 无法读取视频帧，重试...")
                time.sleep(0.5)
                continue
            
            frame_count += 1

            # 1. LED检测
            processed_frame = led_detector.preprocess_frame(frame)
            led_detections = led_detector.detect_leds(processed_frame)
            frame_with_led = led_detector.draw_detections(frame.copy(), led_detections)

            # 2. 仪表检测
            frame_combined = frame_with_led.copy()
            frame_combined, meter_reading = detect_meter(
                frame_combined,
                meter_params, 
                circle_smoother, 
                last_meter_value
            )
            last_meter_value = meter_reading

            # 统计LED检测结果
            led_counts = {color: 0 for color in color_ranges}
            for color, _ in led_detections:
                led_counts[color] += 1

            # ====================== 生成MQTT消息 ======================
            # 生成键值对列表
            count_items = []
            for color, count in led_counts.items():
                count_items.append(f"{color}: {count}")
            
            # 组合成最终字符串
            led_counts_str = "led_counts: {" + ", ".join(count_items) + "}"
            
            # 创建消息主体
            message = {
                **DEVICE_INFO,  # 包含所有设备固定信息
                "data1": round(meter_reading, 2) if meter_reading is not None else 0.0,
                "data2": "true",  # 固定为true，可按需求扩展
                "data3": led_counts_str  # 新格式的LED计数
            }

            # 发布MQTT消息
            if mqtt_handler.connected:
                try:
                    mqtt_handler.publish(json.dumps(message))
                    logging.debug(f"✅ MQTT消息已发送: {json.dumps(message)}")
                except Exception as e:
                    logging.error(f"❌ MQTT发送失败: {str(e)}")

            # 写入最终输出视频文件（保存绘制好的图像）
            out_combined.write(frame_combined)

            # 显示处理后的帧
            cv2.imshow('Video Processing', frame_combined)

            # 处理键盘事件
            key = cv2.waitKey(1)
            if key == ord('q') or key == 27:  # q键或ESC键退出
                logging.info("�� 用户请求退出")
                break

            # 每隔5秒输出状态
            if time.time() - last_status_time > 5:
                elapsed = time.time() - start_time
                actual_fps = frame_count / elapsed if elapsed > 0 else 0
                
                logging.info(
                    f"�� 处理状态: 帧数 {frame_count} | "
                    f"实际FPS: {actual_fps:.1f} | "
                    f"丢失帧: {dropped_frames} | "
                    f"仪表值: {message['data1']} | "
                    f"LED计数: {message['data3']}"
                )
                last_status_time = time.time()

    finally:
        # 资源释放
        cap.release()
        if out_combined is not None and out_combined.isOpened():
            out_combined.release()
        cv2.destroyAllWindows()  # 关闭所有显示窗口
        mqtt_handler.disconnect()
