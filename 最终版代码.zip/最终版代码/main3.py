import cv2
import numpy as np
import math
import json
import logging
import time
import os
from config_loader import ConfigLoader
from mqtt_handler1 import MQTTHandler
from video_ffmpeg6 import process_video  # 合并两个流
from rtmp_pusher1 import push_stream_with_ffmpeg  

# 定义MQTT主题
REQUEST_TOPIC = "DCInspection/request/config/v6"    # 仅初始化请求参数用
SUBSCRIBE_TOPIC = "command/DCInspection/config/v6"  # 订阅配置更新
PUBLISH_TOPIC = "DCInspection/device/v6"            # 后续发送数据的主题
PUSH_STATUS_TOPIC = "DCInspection/push/status/v6"   # 推流状态主题

def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.StreamHandler()]
    )
    
    config_loader = ConfigLoader()
    mqtt_config = config_loader.get_mqtt_config()
    
    # 初始化MQTT处理器
    mqtt_handler = MQTTHandler(
        broker=mqtt_config.get('broker'),
        port=mqtt_config.get('port'),
        topic=PUBLISH_TOPIC,
        username=mqtt_config.get('user'),
        password=mqtt_config.get('password'),
        subscribe_topic=SUBSCRIBE_TOPIC
    )
    mqtt_handler.set_config_loader(config_loader)
    
    if not mqtt_handler.connect():
        logging.error("❌ 无法建立MQTT连接，程序退出")
        return
    
    # 发送配置请求
    request_msg = json.dumps({"request": True})
    if mqtt_handler.publish(request_msg, topic=REQUEST_TOPIC):
        logging.info(f"📤 已发送配置请求: {request_msg} 到主题 {REQUEST_TOPIC}")
    else:
        logging.warning("⚠️ 配置请求发送失败")
    
    # 调用视频处理函数
    process_video(config_loader, mqtt_handler)
    
    try:
        # 推流前发送开始信息
        start_push_msg = json.dumps({"request": True})
        if mqtt_handler.publish(start_push_msg, topic=PUSH_STATUS_TOPIC):
            logging.info(f"📤 已发送推流开始信息: {start_push_msg} 到主题 {PUSH_STATUS_TOPIC}")
        else:
            logging.warning("⚠️ 推流开始信息发送失败")
        
        # 执行推流操作
        push_success = push_stream_with_ffmpeg(
            "combined_output.flv",
            "rtmp://192.168.18.180/video/opencv/54:b2:03:fd:76:0d",
        )
        
        # 推流后发送结束信息，包含推流结果
        end_push_msg = json.dumps({
            "request": False
        })
        if mqtt_handler.publish(end_push_msg, topic=PUSH_STATUS_TOPIC):
            logging.info(f"📤 已发送推流结束信息: {end_push_msg} 到主题 {PUSH_STATUS_TOPIC}")
        else:
            logging.warning("⚠️ 推流结束信息发送失败")
            
    except Exception as e:
        logging.error(f"❌ 推流过程发生错误: {str(e)}")
        # 发生异常时发送错误信息
        error_msg = json.dumps({
            "request": False,
            "success": False,
            "error": str(e)
        })
        mqtt_handler.publish(error_msg, topic=PUSH_STATUS_TOPIC)
    
    mqtt_handler.disconnect()
    logging.info("👋 程序已退出")

if __name__ == '__main__':
    main()