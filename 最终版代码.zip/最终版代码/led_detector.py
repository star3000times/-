#使用opencv来识别指示灯
import cv2
import numpy as np

class LEDDetector:
    def __init__(self, color_ranges, min_area, draw_colors=None, nms_threshold=0.3):
        self.color_ranges = color_ranges
        self.min_area = min_area
        self.draw_colors = draw_colors or {}
        self.nms_threshold = nms_threshold
        # 初始化形态学操作核
        self.kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))

    def update_parameters(self, color_ranges=None, min_area=None, draw_colors=None):
        """更新检测参数"""
        if color_ranges is not None:
            self.color_ranges = color_ranges
        if min_area is not None:
            self.min_area = min_area
        if draw_colors is not None:
            self.draw_colors = draw_colors

    def preprocess_frame(self, frame):
        """预处理帧：高斯滤波"""
        return cv2.GaussianBlur(frame, (5, 5), 0)

    def detect_leds(self, frame):
        """检测指示灯并返回结果"""
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        detections = []

        for color, ranges in self.color_ranges.items():
            # 创建颜色掩码
            if isinstance(ranges, list):
                mask = None
                for (low, high) in ranges:
                    current_mask = cv2.inRange(hsv, np.array(low), np.array(high))
                    mask = current_mask if mask is None else cv2.bitwise_or(mask, current_mask)
            else:
                low, high = ranges
                mask = cv2.inRange(hsv, np.array(low), np.array(high))
            
            # 形态学闭运算
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, self.kernel, iterations=2)
            cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            # 收集有效轮廓
            boxes = []
            for c in cnts:
                area = cv2.contourArea(c)
                if area > self.min_area:
                    x, y, w, h = cv2.boundingRect(c)
                    boxes.append((x, y, x + w, y + h, area, color))
            
            # 非极大值抑制
            boxes.sort(key=lambda b: b[4], reverse=True)
            nms_boxes = []
            
            while boxes:
                current = boxes.pop(0)
                nms_boxes.append(current)
                remaining = []
                for box in boxes:
                    # 计算交并比
                    x1, y1, x2, y2, _, _ = current
                    x1b, y1b, x2b, y2b, _, _ = box
                    
                    inter_x1 = max(x1, x1b)
                    inter_y1 = max(y1, y1b)
                    inter_x2 = min(x2, x2b)
                    inter_y2 = min(y2, y2b)
                    inter_area = max(0, inter_x2 - inter_x1) * max(0, inter_y2 - inter_y1)
                    
                    current_area = (x2 - x1) * (y2 - y1)
                    box_area = (x2b - x1b) * (y2b - y1b)
                    union_area = current_area + box_area - inter_area
                    
                    iou = inter_area / union_area if union_area != 0 else 0
                    
                    if iou < self.nms_threshold:
                        remaining.append(box)
                boxes = remaining
            
            # 转换格式并添加到检测结果
            for (x1, y1, x2, y2, _, color) in nms_boxes:
                detections.append((color, (x1, y1, x2 - x1, y2 - y1)))
        
        return detections

    def draw_detections(self, frame, detections):
        """在帧上绘制检测结果"""
        frame_copy = frame.copy()
        for color, (x, y, w, h) in detections:
            color_val = self.draw_colors.get(color, (0, 255, 0))  # 默认绿色
            cv2.rectangle(frame_copy, (x, y), (x+w, y+h), color_val, 2)
            cv2.putText(frame_copy, color, (x, y-10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 1.5, color_val, 2)
        return frame_copy