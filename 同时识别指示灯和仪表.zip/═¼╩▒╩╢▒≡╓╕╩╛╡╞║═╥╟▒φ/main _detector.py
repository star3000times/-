import cv2
import numpy as np
import math
import json
import logging
import time
import os
from config_loader import ConfigLoader
from mqtt_handler import MQTTHandler
from led_detector import LEDDetector  # LED检测器
from meter_detector import CircleSmoother, detect_meter  # 仪表检测器

def process_video(config_loader, mqtt_handler):
    logging.info("⌛ 等待MQTT发送配置参数...")
    while True:
        # 检查是否从MQTT收到完整配置（需包含LED和仪表所需参数）
        if config_loader.mqtt_updated:
            required_keys = ['hsv_ranges', 'video', 'detection', 'mqtt']
            if all(key in config_loader.config for key in required_keys):
                video_source = config_loader.get_video_source()
                is_valid_source = (video_source.isdigit() or 
                                  (isinstance(video_source, str) and os.path.isfile(video_source)))
                
                if is_valid_source:
                    logging.info("✅ 已收到完整配置，开始检测流程")
                    break
        
        # 保持MQTT连接
        if not mqtt_handler.connected:
            mqtt_handler.reconnect()
        
        time.sleep(1)

    # 初始化配置参数
    # LED相关参数
    color_ranges = config_loader.get_hsv_ranges()
    draw_colors = config_loader.get_draw_colors()
    min_area = config_loader.get_min_area()
    
    # 仪表相关参数
    meter_params = config_loader.get_meter_params()
    last_meter_value = meter_params.get("min_value", 0)
    circle_smoother = CircleSmoother(buffer_size=10)
    
    # 视频源和输出配置
    source = config_loader.get_video_source()
    output_led_path = config_loader.get_video_output_led()  # LED检测输出路径
    output_meter_path = config_loader.get_video_output_meter()  # 仪表检测输出路径

    # 创建检测器实例
    led_detector = LEDDetector(
        color_ranges=color_ranges,
        min_area=min_area,
        draw_colors=draw_colors
    )

    # 打开视频源
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        logging.error("❌ 无法打开视频源")
        return

    # 获取视频参数
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    # 初始化两个视频输出（LED和仪表）
    codecs = ['MJPG', 'XVID', 'DIVX', 'mp4v']
    out_led = None
    out_meter = None

    # 初始化LED输出
    for codec in codecs:
        try:
            fourcc = cv2.VideoWriter_fourcc(*codec)
            out_led = cv2.VideoWriter(output_led_path, fourcc, fps, (width, height))
            if out_led.isOpened():
                logging.info(f"LED输出使用编解码器: {codec}")
                break
        except:
            continue
    if out_led is None:
        logging.error("❌ 无法初始化LED视频输出")
        return

    # 初始化仪表输出
    for codec in codecs:
        try:
            fourcc = cv2.VideoWriter_fourcc(*codec)
            out_meter = cv2.VideoWriter(output_meter_path, fourcc, fps, (width, height))
            if out_meter.isOpened():
                logging.info(f"仪表输出使用编解码器: {codec}")
                break
        except:
            continue
    if out_meter is None:
        logging.error("❌ 无法初始化仪表视频输出")
        out_led.release()
        return

    # 创建显示窗口
    cv2.namedWindow("LED Detection", cv2.WINDOW_NORMAL)
    cv2.resizeWindow("LED Detection", 1280, 720)
    cv2.namedWindow("Meter Reading", cv2.WINDOW_NORMAL)
    cv2.resizeWindow("Meter Reading", 1280, 720)
    cv2.namedWindow("Preprocessed Frame", cv2.WINDOW_NORMAL)
    cv2.resizeWindow("Preprocessed Frame", 1280, 720)

    try:
        while True:
            # 检查配置更新
            if config_loader.check_for_updates():
                # 更新LED参数
                new_color_ranges = config_loader.get_hsv_ranges()
                new_draw_colors = config_loader.get_draw_colors()
                new_min_area = config_loader.get_min_area()
                led_detector.update_parameters(
                    color_ranges=new_color_ranges,
                    min_area=new_min_area,
                    draw_colors=new_draw_colors
                )

                # 更新仪表参数
                new_meter_params = config_loader.get_meter_params()
                meter_params = new_meter_params
                last_meter_value = meter_params.get("min_value", last_meter_value)

                # 更新MQTT配置
                mqtt_config = config_loader.get_mqtt_config()
                mqtt_handler.update_config(
                    broker=mqtt_config.get('broker'),
                    port=mqtt_config.get('port'),
                    topic=mqtt_config.get('topic'),
                    username=mqtt_config.get('user'),
                    password=mqtt_config.get('password'),
                    subscribe_topic=mqtt_config.get('subscribe_topic')
                )

                # 处理视频源变更
                new_source = config_loader.get_video_source()
                if new_source != source:
                    source = new_source
                    cap.release()
                    cap = cv2.VideoCapture(source)
                    if not cap.isOpened():
                        logging.error("❌ 无法打开新视频源")
                        break

                # 处理LED输出路径变更
                new_output_led = config_loader.get_video_output_led()
                if new_output_led != output_led_path:
                    output_led_path = new_output_led
                    out_led.release()
                    for codec in codecs:
                        try:
                            fourcc = cv2.VideoWriter_fourcc(*codec)
                            out_led = cv2.VideoWriter(output_led_path, fourcc, fps, (width, height))
                            if out_led.isOpened():
                                logging.info(f"LED输出切换编解码器: {codec}")
                                break
                        except:
                            continue

                # 处理仪表输出路径变更
                new_output_meter = config_loader.get_video_output_meter()
                if new_output_meter != output_meter_path:
                    output_meter_path = new_output_meter
                    out_meter.release()
                    for codec in codecs:
                        try:
                            fourcc = cv2.VideoWriter_fourcc(*codec)
                            out_meter = cv2.VideoWriter(output_meter_path, fourcc, fps, (width, height))
                            if out_meter.isOpened():
                                logging.info(f"仪表输出切换编解码器: {codec}")
                                break
                        except:
                            continue

            # 读取视频帧
            ret, frame = cap.read()
            if not ret:
                logging.warning("⚠️ 无法读取视频帧，重试...")
                time.sleep(0.5)
                continue

            # 1. 先进行LED检测
            processed_frame = led_detector.preprocess_frame(frame)
            led_detections = led_detector.detect_leds(processed_frame)
            frame_with_led = led_detector.draw_detections(frame.copy(), led_detections)

            # 2. 再进行仪表检测（使用原始帧或LED处理后的帧）
            frame_with_meter, meter_reading = detect_meter(
                frame.copy(),  # 可改为frame_with_led使用LED检测后的帧
                meter_params, 
                circle_smoother, 
                last_meter_value
            )
            last_meter_value = meter_reading  # 更新仪表上一次读数

            # 统计LED检测结果
            led_counts = {color: 0 for color in color_ranges}
            for color, _ in led_detections:
                led_counts[color] += 1

            # 合并结果并发布到MQTT
            if mqtt_handler.connected:
                combined_result = {
                    "led_counts": led_counts,
                    "meter_reading": round(meter_reading, 2) if meter_reading is not None else None
                }
                mqtt_handler.publish(json.dumps(combined_result))

            # 写入输出视频
            out_led.write(frame_with_led)
            out_meter.write(frame_with_meter)

            # 显示结果
            cv2.imshow("LED Detection", frame_with_led)
            cv2.imshow("Meter Reading", frame_with_meter)
            cv2.imshow("Preprocessed Frame", processed_frame)

            # 处理键盘事件
            key = cv2.waitKey(1)
            if key == ord('q') or key == 27:  # ESC或Q退出
                logging.info("🔍 用户请求退出")
                break
            # 仪表角度偏移调整
            elif key == ord('.') or key == ord('>'):
                meter_params["angle_offset"] = (meter_params.get("angle_offset", 0) + 5) % 360
                logging.info(f"角度偏移调整为: {meter_params['angle_offset']}°")
            elif key == ord(',') or key == ord('<'):
                meter_params["angle_offset"] = (meter_params.get("angle_offset", 0) - 5) % 360
                logging.info(f"角度偏移调整为: {meter_params['angle_offset']}°")

    finally:
        # 资源释放
        cap.release()
        out_led.release()
        out_meter.release()
        cv2.destroyAllWindows()

def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.StreamHandler()]
    )
    
    config_loader = ConfigLoader()
    mqtt_config = config_loader.get_mqtt_config()
    
    # 初始化MQTT处理器
    mqtt_handler = MQTTHandler(
        broker=mqtt_config.get('broker'),
        port=mqtt_config.get('port'),
        topic=mqtt_config.get('topic'),
        username=mqtt_config.get('user'),
        password=mqtt_config.get('password'),
        subscribe_topic=mqtt_config.get('subscribe_topic')
    )
    mqtt_handler.set_config_loader(config_loader)
    
    if not mqtt_handler.connect():
        logging.error("❌ 无法建立MQTT连接，程序退出")
        return
    
    # 发送配置请求（需包含LED和仪表参数）
    request_msg = json.dumps({"request": True, "needs": ["led_params", "meter_params"]})
    if mqtt_handler.publish(request_msg):
        logging.info(f"📤 已发送配置请求: {request_msg} 到主题 {mqtt_config.get('topic')}")
    else:
        logging.warning("⚠️ 配置请求发送失败")
    
    process_video(config_loader, mqtt_handler)
    
    mqtt_handler.disconnect()
    logging.info("📌 程序已退出")

if __name__ == '__main__':
    main()