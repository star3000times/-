# SRS控制台（实际不一定用这个端口用默认端口就行）：http://192.168.18.164:8080/
# 端口号
# 使用RTMP推流
# 其中meterdetector和leddetector分别是用来识别仪表和指示灯的
# 启动main_detector后，服务器发送json文件作为参数后开始识别
# 返回2个视频，发送参数到对应的服务器上