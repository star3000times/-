import paho.mqtt.client as mqtt
from paho.mqtt.client import CallbackAPIVersion
import logging
import time

class MQTTHandler:
    def __init__(self, broker, port, topic, username, password, subscribe_topic):
        """初始化MQTT处理器（使用传入的固定主题）"""
        self.broker = broker
        self.port = port
        self.topic = topic  
        self.subscribe_topic = subscribe_topic  
        self.username = username
        self.password = password
        self.connected = False
        self.config_loader = None  # 配置加载器引用
        self.client = self._create_client()

    def set_config_loader(self, config_loader):
        """关联配置加载器，用于更新配置"""
        self.config_loader = config_loader

    def _create_client(self):
        """创建客户端并绑定回调"""
        client = mqtt.Client(callback_api_version=CallbackAPIVersion.VERSION2)
        client.username_pw_set(self.username, self.password)
        
        # 绑定回调
        client.on_connect = self._on_connect
        client.on_disconnect = self._on_disconnect
        client.on_publish = self._on_publish
        client.on_message = self._on_message  # 消息接收回调
        return client

    def _on_message(self, client, userdata, msg):
        """处理收到的订阅消息（主要处理配置更新）"""
        try:
            payload = msg.payload.decode('utf-8')
            logging.info(f"�� 收到订阅消息 [主题: {msg.topic}] 内容: {payload[:100]}...")  # 显示前100字符
            
            # 如果是配置主题的消息，更新配置
            if msg.topic == self.subscribe_topic and self.config_loader:
                self.config_loader.update_from_mqtt(payload)
        except Exception as e:
            logging.error(f"❌ 消息处理失败: {str(e)}")

    def update_config(self, broker, port, topic, username, password, subscribe_topic):
        """更新配置（仅更新非主题参数，主题保持初始化时的固定值）"""
        # 仅比较非主题参数是否变化
        if (self.broker == broker and self.port == port and 
            self.username == username and self.password == password):
            return True
            
        # 仅更新非主题参数
        self.broker = broker
        self.port = port
        self.username = username
        self.password = password
        
        # 主题保持初始化时的固定值，不更新
        # self.topic = topic  # 注释掉，固定主题
        # self.subscribe_topic = subscribe_topic  # 注释掉，固定主题
        
        # 重新连接
        self.disconnect()
        self.client = self._create_client()
        return self.connect()

    def _on_connect(self, client, userdata, flags, rc, properties, *args):
        """连接成功后自动订阅固定主题"""
        if rc == 0:
            self.connected = True
            logging.info(f"✅ MQTT连接成功！返回码: {rc}")
            # 订阅固定主题
            if self.subscribe_topic:
                result, mid = self.client.subscribe(self.subscribe_topic)
                if result == 0:
                    logging.info(f"✅ 成功订阅固定主题: {self.subscribe_topic}")
                else:
                    logging.error(f"❌ 订阅固定主题失败，返回码: {result}")
        else:
            self.connected = False
            logging.error(f"❌ MQTT连接失败！返回码: {rc}，原因: {mqtt.connack_string(rc)}")

    def _on_disconnect(self, client, userdata, rc, properties, *args):
        self.connected = False
        if rc != 0:
            logging.warning(f"⚠️ MQTT意外断开连接！返回码: {rc}")
        else:
            logging.info("�� MQTT已正常断开连接")

    def _on_publish(self, client, userdata, mid, reason_code, properties):
        logging.info(f"�� 消息发布成功 (消息ID: {mid})")

    def connect(self, timeout=5):
        try:
            self.client.connect(self.broker, self.port, keepalive=60)
            self.client.loop_start()
            start_time = time.time()
            while not self.connected and time.time() - start_time < timeout:
                time.sleep(0.1)
            return self.connected
        except Exception as e:
            logging.error(f"❌ MQTT连接异常: {str(e)}")
            return False

    def reconnect(self, max_attempts=3, delay=2):
        for attempt in range(max_attempts):
            logging.info(f"⚠️ 尝试第 {attempt+1}/{max_attempts} 次重连...")
            if self.connect(timeout=5):
                return True
            time.sleep(delay)
        return False

    def publish(self, payload, max_attempts=2, topic=None):
        """发布消息，支持指定主题（默认使用初始化的主题）"""
        if not self.connected:
            logging.warning("⚠️ MQTT未连接，无法发布消息")
            return False

        # 优先使用传入的topic，否则使用初始化的self.topic
        publish_topic = topic if topic is not None else self.topic

        for attempt in range(max_attempts):
            try:
                result = self.client.publish(publish_topic, payload)  # 使用指定主题发布
                result.wait_for_publish(timeout=1.0)
                if result.is_published():
                    logging.info(f"�� 发送数据到主题 {publish_topic}: {payload}")
                    return True
                else:
                    logging.warning(f"⚠️ 发布到主题 {publish_topic} 失败，重试第 {attempt+1} 次")
            except Exception as e:
                logging.error(f"⚠️ 发布到主题 {publish_topic} 异常，重试第 {attempt+1} 次: {str(e)}")
        return False

    def disconnect(self):
        self.client.loop_stop()
        self.client.disconnect()
        self.connected = False