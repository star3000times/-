import subprocess
import logging

def push_stream_with_ffmpeg(video_path, rtmp_url):
    """
    使用FFmpeg将视频文件推流到RTMP服务器，关闭B帧
    
    参数:
        video_path: 视频文件路径
        rtmp_url: RTMP推流地址
    """
    try:
        # 构建FFmpeg命令，关闭B帧(-bf 0)
        # -vcodec libx264: 使用H.264编码器
        # -bf 0: 关闭B帧
        # -preset ultrafast: 最快编码速度（可根据需求调整）
        # -f flv: 输出FLV格式（RTMP常用）
        cmd = [
            'ffmpeg',
            '-i', video_path,          # 输入视频文件
            '-vcodec', 'libx264',      # 视频编码器
            '-bf', '0',                # 关闭B帧
            '-preset', 'ultrafast',    # 编码速度预设
            '-f', 'flv',               # 输出格式
            rtmp_url                   # 推流地址
        ]
        
        logging.info(f"开始推流到RTMP服务器: {rtmp_url}")
        logging.info(f"执行FFmpeg命令: {' '.join(cmd)}")
        
        # 执行命令并捕获输出
        process = subprocess.run(
            cmd,
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )
        
        logging.info("FFmpeg推流完成")
        return True
        
    except FileNotFoundError:
        logging.error("未找到FFmpeg可执行文件，请确保FFmpeg已安装并添加到环境变量")
        return False
    except subprocess.CalledProcessError as e:
        logging.error(f"FFmpeg推流失败，返回码: {e.returncode}")
        logging.error(f"输出信息: {e.stdout}")
        return False
    except Exception as e:
        logging.error(f"推流过程发生错误: {str(e)}")
        return False

