进入code文件夹，打开终端，启动conda虚拟环境，后安装提示需要的库
运行main1.py即可启动程序，然后服务器再来修改json参数
服务器发送后json文件后直接修改本地的config.json文件
json文件的参数不能少，不然会无法接收
config.json可以调整的参数有HSV和RGB的阈值，识别的区域范围（根据摄像头的精度参数调节），摄像头的地址rtep如：rtsp://admin:password@192.168.1.100:554/stream1或者本地视频地址：C:/Users/UserX/Desktop/code/MP44.mp4
在main1.py中新增了图像预处理部分，需要根据相应情景调整参数