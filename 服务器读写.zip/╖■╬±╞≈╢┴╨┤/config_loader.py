import json
import os
import time
import logging

class ConfigLoader:
    def __init__(self, config_path="config.json"):
        self.config_path = config_path
        self.config = None
        self.last_modified = 0
        self.load_config()
        self.mqtt_updated = False  #标记是否从MQTT更新过配置

    def load_config(self):
        """从文件加载配置"""
        try:
            current_modified = os.path.getmtime(self.config_path)
            if current_modified > self.last_modified:
                with open(self.config_path, 'r') as f:
                    self.config = json.load(f)
                self.last_modified = current_modified
                logging.info("✅ 配置文件已加载/更新（从文件）")
                return True
            return False
        except Exception as e:
            logging.error(f"❌ 加载配置文件失败: {str(e)}")
            return False

    def update_from_mqtt(self, config_str):
        """从MQTT接收的字符串更新配置"""
        try:
            new_config = json.loads(config_str)
            # 验证配置结构完整性
            required_keys = ['mqtt', 'hsv_ranges', 'draw_colors', 'detection', 'video']
            if all(key in new_config for key in required_keys):
                self.config = new_config
                # 同时更新本地文件（可选，便于持久化）
                with open(self.config_path, 'w') as f:
                    json.dump(new_config, f, indent=2)
                self.last_modified = os.path.getmtime(self.config_path)
                self.mqtt_updated = True  # 标记已通过MQTT更新
                logging.info("✅ 配置已从MQTT更新")
                return True
            else:
                logging.error("❌ MQTT配置格式不完整，缺少必要字段")
                return False
        except json.JSONDecodeError:
            logging.error("❌ MQTT配置解析失败，不是有效的JSON")
            return False
        except Exception as e:
            logging.error(f"❌ MQTT配置更新失败: {str(e)}")
            return False

    def check_for_updates(self):
        """检查文件更新（保留原功能）"""
        return self.load_config()

    # 以下方法保持不变
    def get_mqtt_config(self):
        return self.config.get('mqtt', {})

    def get_hsv_ranges(self):
        hsv_config = self.config.get('hsv_ranges', {})
        color_ranges = {}
        for color, ranges in hsv_config.items():
            converted_ranges = []
            for r in ranges:
                converted_ranges.append((tuple(r['low']), tuple(r['high'])))
            color_ranges[color] = converted_ranges if len(converted_ranges) > 1 else converted_ranges[0]
        return color_ranges

    def get_draw_colors(self):
        draw_config = self.config.get('draw_colors', {})
        return {k: tuple(v) for k, v in draw_config.items()}

    def get_min_area(self):
        return self.config.get('detection', {}).get('min_area', 100)

    def get_video_source(self):
        return self.config.get('video', {}).get('source', 0)