import cv2
import numpy as np
import json
import time
import logging
from config_loader import ConfigLoader
from mqtt_handler import MQTTHandler

# 以下detect_leds、draw_detections函数保持不变
def detect_leds(frame, color_ranges, min_area):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    detections = []
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5,5))

    for color, ranges in color_ranges.items():
        if isinstance(ranges, list):
            mask = None
            for (low, high) in ranges:
                current_mask = cv2.inRange(hsv, np.array(low), np.array(high))
                mask = current_mask if mask is None else cv2.bitwise_or(mask, current_mask)
        else:
            low, high = ranges
            mask = cv2.inRange(hsv, np.array(low), np.array(high))
            
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        for c in cnts:
            if cv2.contourArea(c) > min_area:
                x, y, w, h = cv2.boundingRect(c)
                detections.append((color, (x, y, w, h)))
    return detections

def draw_detections(frame, detections, draw_colors):
    for color, (x, y, w, h) in detections:
        cv2.rectangle(frame, (x, y), (x+w, y+h), draw_colors[color], 2)
        cv2.putText(frame, color, (x, y-10), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1.5, draw_colors[color], 2)
    return frame

def process_video(config_loader, mqtt_handler):
    color_ranges = config_loader.get_hsv_ranges()
    draw_colors = config_loader.get_draw_colors()
    min_area = config_loader.get_min_area()
    source = config_loader.get_video_source()

    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        logging.error("❌ 无法打开视频源")
        return

    cv2.namedWindow("LED Detection", cv2.WINDOW_NORMAL)
    cv2.resizeWindow("LED Detection", 1280, 720)

    try:
        while True:
            if config_loader.check_for_updates():
                new_color_ranges = config_loader.get_hsv_ranges()
                new_draw_colors = config_loader.get_draw_colors()
                new_min_area = config_loader.get_min_area()
                new_source = config_loader.get_video_source()
                mqtt_config = config_loader.get_mqtt_config()
                
                # 更新MQTT配置（新增订阅主题参数）
                mqtt_handler.update_config(
                    broker=mqtt_config.get('broker'),
                    port=mqtt_config.get('port'),
                    topic=mqtt_config.get('topic'),
                    username=mqtt_config.get('user'),
                    password=mqtt_config.get('password'),
                    subscribe_topic=mqtt_config.get('subscribe_topic')  # 新增
                )
                
                color_ranges = new_color_ranges
                draw_colors = new_draw_colors
                min_area = new_min_area
                
                if new_source != source:
                    source = new_source
                    cap.release()
                    cap = cv2.VideoCapture(source)
                    if not cap.isOpened():
                        logging.error("❌ 无法打开新的视频源")
                        break

            ret, frame = cap.read()
            if not ret:
                logging.warning("⚠️ 无法读取视频帧，重试...")
                time.sleep(0.5)
                continue

            if not mqtt_handler.connected:
                if not mqtt_handler.reconnect():
                    logging.error("❌ MQTT重连失败，退出程序")
                    break

            detections = detect_leds(frame, color_ranges, min_area)
            frame = draw_detections(frame, detections, draw_colors)

            counts = {color: 0 for color in color_ranges}
            for color, _ in detections:
                counts[color] += 1
            mqtt_handler.publish(json.dumps(counts))

            cv2.imshow("LED Detection", frame)
            
            if cv2.waitKey(1) & 0xFF == 27:
                logging.info("🔍 用户请求退出")
                break

    finally:
        cap.release()
        cv2.destroyAllWindows()

def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.StreamHandler()]
    )
    
    config_loader = ConfigLoader()
    mqtt_config = config_loader.get_mqtt_config()
    
    # 初始化MQTT处理器（新增订阅主题参数）
    mqtt_handler = MQTTHandler(
        broker=mqtt_config.get('broker'),
        port=mqtt_config.get('port'),
        topic=mqtt_config.get('topic'),
        username=mqtt_config.get('user'),
        password=mqtt_config.get('password'),
        subscribe_topic=mqtt_config.get('subscribe_topic')  # 新增
    )
    # 关联配置加载器到MQTT处理器
    mqtt_handler.set_config_loader(config_loader)
    
    if not mqtt_handler.connect():
        logging.error("❌ 无法建立MQTT连接，程序退出")
        return
    
    process_video(config_loader, mqtt_handler)
    
    mqtt_handler.disconnect()
    logging.info("📌 程序已退出")

if __name__ == '__main__':
    main()