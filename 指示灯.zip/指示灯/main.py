import cv2
import numpy as np
import json
import time
import logging
from config import init_logging, parse_arguments, get_color_ranges, DRAW_COLORS
from mqtt_handler import MQTTHandler

def detect_leds(frame, color_ranges, min_area):
    """识别图像中的LED灯并返回检测结果"""
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    detections = []
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5,5))

    for color, (low, high) in color_ranges.items():
        mask = cv2.inRange(hsv, np.array(low), np.array(high))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        for c in cnts:
            if cv2.contourArea(c) > min_area:
                x, y, w, h = cv2.boundingRect(c)
                detections.append((color, (x, y, w, h)))
    return detections

def draw_detections(frame, detections):
    """在图像上绘制检测结果"""
    for color, (x, y, w, h) in detections:
        cv2.rectangle(frame, (x, y), (x+w, y+h), DRAW_COLORS[color], 2)
        cv2.putText(frame, color, (x, y-10), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1.5, DRAW_COLORS[color], 2)
    return frame

def process_video(source, mqtt_handler, color_ranges, min_area):
    """处理视频源并上传检测数据"""
    # 打开视频源
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        logging.error("❌ 无法打开视频源")
        return

    # 初始化显示窗口
    cv2.namedWindow("LED Detection", cv2.WINDOW_NORMAL)
    cv2.resizeWindow("LED Detection", 1280, 720)

    try:
        while True:
            # 读取视频帧
            ret, frame = cap.read()
            if not ret:
                logging.warning("⚠️ 无法读取视频帧，重试...")
                time.sleep(0.5)
                continue

            # 检查MQTT连接状态
            if not mqtt_handler.connected:
                if not mqtt_handler.reconnect():
                    logging.error("❌ MQTT重连失败，退出程序")
                    break

            # 检测LED
            detections = detect_leds(frame, color_ranges, min_area)
            
            # 绘制检测结果
            frame = draw_detections(frame, detections)

            # 统计颜色数量并上传
            counts = {color: 0 for color in color_ranges}
            for color, _ in detections:
                counts[color] += 1
            mqtt_handler.publish(json.dumps(counts))

            # 显示图像
            cv2.imshow("LED Detection", frame)
            
            # 按ESC退出
            if cv2.waitKey(1) & 0xFF == 27:
                logging.info("🔍 用户请求退出")
                break

    finally:
        # 资源清理
        cap.release()
        cv2.destroyAllWindows()

def main():
    # 初始化日志
    init_logging()
    
    # 解析配置参数
    args = parse_arguments()
    color_ranges = get_color_ranges(args)
    
    # 初始化MQTT处理器
    mqtt_handler = MQTTHandler(
        broker=args.mqtt_broker,
        port=args.mqtt_port,
        topic=args.mqtt_topic
    )
    
    # 建立MQTT连接
    if not mqtt_handler.connect():
        logging.error("❌ 无法建立MQTT连接，程序退出")
        return
    
    # 处理视频源并上传数据（主功能）
    process_video(
        source=args.source,
        mqtt_handler=mqtt_handler,
        color_ranges=color_ranges,
        min_area=args.min_area
    )
    
    # 断开连接
    mqtt_handler.disconnect()
    logging.info("📌 程序已退出")

if __name__ == '__main__':
    main()