import paho.mqtt.client as mqtt
from paho.mqtt.client import CallbackAPIVersion
import logging
import time
from config import DEFAULT_MQTT_USER, DEFAULT_MQTT_PASS

class MQTTHandler:
    def __init__(self, broker, port, topic):
        self.broker = broker
        self.port = port
        self.topic = topic
        self.connected = False  # 连接状态标识
        self.client = self._create_client()

    def _create_client(self):
        """创建MQTT客户端并绑定回调"""
        client = mqtt.Client(callback_api_version=CallbackAPIVersion.VERSION2)
        client.username_pw_set(DEFAULT_MQTT_USER, DEFAULT_MQTT_PASS)
        
        # 绑定回调函数
        client.on_connect = self._on_connect
        client.on_disconnect = self._on_disconnect
        client.on_publish = self._on_publish
        return client

    def _on_connect(self, client, userdata, flags, rc, properties):
        """连接回调函数"""
        if rc == 0:
            self.connected = True
            logging.info(f"✅ MQTT连接成功！返回码: {rc}")
        else:
            self.connected = False
            logging.error(f"❌ MQTT连接失败！返回码: {rc}，原因: {mqtt.connack_string(rc)}")

    def _on_disconnect(self, client, userdata, rc, properties):
        """断开连接回调函数"""
        self.connected = False
        if rc != 0:
            logging.warning(f"⚠️ MQTT意外断开连接！返回码: {rc}")
        else:
            logging.info("🔌 MQTT已正常断开连接")

    def _on_publish(self, client, userdata, mid, reason_code, properties):
        """发布成功回调函数"""
        logging.info(f"📤 消息发布成功 (消息ID: {mid})")

    def connect(self, timeout=5):
        """建立MQTT连接"""
        try:
            self.client.connect(self.broker, self.port, keepalive=60)
            self.client.loop_start()  # 启动网络循环线程
            
            # 等待连接成功
            start_time = time.time()
            while not self.connected and time.time() - start_time < timeout:
                time.sleep(0.1)
            return self.connected
        except Exception as e:
            logging.error(f"❌ MQTT连接异常: {str(e)}")
            return False

    def reconnect(self, max_attempts=3, delay=2):
        """尝试重连MQTT"""
        for attempt in range(max_attempts):
            logging.info(f"⚠️ 尝试第 {attempt+1}/{max_attempts} 次重连...")
            if self.connect(timeout=5):
                return True
            time.sleep(delay)
        return False

    def publish(self, payload, max_attempts=2):
        """发布消息（带重试）"""
        if not self.connected:
            logging.warning("⚠️ MQTT未连接，无法发布消息")
            return False

        for attempt in range(max_attempts):
            try:
                result = self.client.publish(self.topic, payload)
                result.wait_for_publish(timeout=1.0)
                if result.is_published():
                    logging.info(f"📊 发送数据: {payload}")
                    return True
                else:
                    logging.warning(f"⚠️ 发布失败，重试第 {attempt+1} 次")
            except Exception as e:
                logging.error(f"⚠️ 发布异常，重试第 {attempt+1} 次: {str(e)}")
        return False

    def disconnect(self):
        """断开MQTT连接"""
        self.client.loop_stop()
        self.client.disconnect()
        self.connected = False