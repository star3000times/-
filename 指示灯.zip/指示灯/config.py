import argparse
import logging

# 默认MQTT配置
DEFAULT_MQTT_BROKER = "192.168.18.164"
DEFAULT_MQTT_PORT = 1883
DEFAULT_MQTT_TOPIC = "DCInspection/device/v6"
DEFAULT_MQTT_USER = "user1"
DEFAULT_MQTT_PASS = "axjIWLAMMXA.SAKFN5321ZASHV"

# 默认HSV颜色范围(需要配置)
DEFAULT_COLOR_RANGES = {
    'red':    [((0, 120, 120), (10, 255, 255)), ((170, 120, 120), (180, 255, 255))],  # 红色两个范围
    'yellow': ((20, 120, 120), (30, 255, 255)),
    'green':  ((50, 120, 120), (70, 255, 255)),
    'blue':   ((100, 120, 120), (130, 255, 255)),
}

# 绘制颜色RGB(需要配置)
DRAW_COLORS = {
    'red':    (0, 0, 255),
    'yellow': (0, 255, 255),
    'green':  (0, 255, 0),
    'blue':   (255, 0, 0),
}

def init_logging():
    """初始化日志配置"""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.StreamHandler()]
    )

def parse_arguments():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description="LED Detection with MQTT")
    parser.add_argument('--source', default=0, help="视频源（文件路径、RTSP地址或摄像头ID，默认0）")
    parser.add_argument('--min-area', type=int, default=100, help="最小轮廓面积阈值（默认100）")#(default=100需要配置)
    parser.add_argument('--mqtt-broker', default=DEFAULT_MQTT_BROKER, help=f"MQTT服务器地址（默认{DEFAULT_MQTT_BROKER}）")
    parser.add_argument('--mqtt-port', type=int, default=DEFAULT_MQTT_PORT, help=f"MQTT端口（默认{DEFAULT_MQTT_PORT}）")
    parser.add_argument('--mqtt-topic', default=DEFAULT_MQTT_TOPIC, help=f"MQTT主题（默认{DEFAULT_MQTT_TOPIC}）")
    # 红色需要两个范围的参数
    parser.add_argument('--hsv-red1', nargs=6, type=int, default=[0,120,120,10,255,255], 
                       help="红色HSV范围1（low_h low_s low_v high_h high_s high_v）")
    parser.add_argument('--hsv-red2', nargs=6, type=int, default=[170,120,120,180,255,255], 
                       help="红色HSV范围2（low_h low_s low_v high_h high_s high_v）")
    parser.add_argument('--hsv-yellow', nargs=6, type=int, default=[20,120,120,30,255,255], 
                       help="黄色HSV范围（low_h low_s low_v high_h high_s high_v）")
    parser.add_argument('--hsv-green', nargs=6, type=int, default=[50,120,120,70,255,255], 
                       help="绿色HSV范围（low_h low_s low_v high_h high_s high_v）")
    parser.add_argument('--hsv-blue', nargs=6, type=int, default=[100,120,120,130,255,255], 
                       help="蓝色HSV范围（low_h low_s low_v high_h high_s high_v）")
    return parser.parse_args()

def get_color_ranges(args):#动态读取参数配置
    """根据参数生成颜色范围配置"""
    return {
        'red': [
            ((args.hsv_red1[0], args.hsv_red1[1], args.hsv_red1[2]),
             (args.hsv_red1[3], args.hsv_red1[4], args.hsv_red1[5])),
            ((args.hsv_red2[0], args.hsv_red2[1], args.hsv_red2[2]),
             (args.hsv_red2[3], args.hsv_red2[4], args.hsv_red2[5]))
        ],  
        'yellow': ((args.hsv_yellow[0], args.hsv_yellow[1], args.hsv_yellow[2]),
                  (args.hsv_yellow[3], args.hsv_yellow[4], args.hsv_yellow[5])),
        'green': ((args.hsv_green[0], args.hsv_green[1], args.hsv_green[2]),
                 (args.hsv_green[3], args.hsv_green[4], args.hsv_green[5])),
        'blue': ((args.hsv_blue[0], args.hsv_blue[1], args.hsv_blue[2]),
                (args.hsv_blue[3], args.hsv_blue[4], args.hsv_blue[5])),
    }
