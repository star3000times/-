import cv2
import numpy as np
import json
import time
import logging
from config_loader import ConfigLoader
from mqtt_handler import MQTTHandler

# 新增：视频帧预处理函数，默认使用高斯滤波
def preprocess_frame(frame):
    # 高斯模糊 - 用于平滑图像，减少高频噪声
    return cv2.GaussianBlur(frame, (5, 5), 0)

def detect_leds(frame, color_ranges, min_area):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    detections = []
    # 增大卷积核并改用闭运算增强区域合并
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
    # NMS重叠阈值（可根据实际场景调整，0.3表示重叠30%以上会被过滤）
    nms_threshold = 0.3

    for color, ranges in color_ranges.items():
        if isinstance(ranges, list):
            mask = None
            for (low, high) in ranges:
                current_mask = cv2.inRange(hsv, np.array(low), np.array(high))
                mask = current_mask if mask is None else cv2.bitwise_or(mask, current_mask)
        else:
            low, high = ranges
            mask = cv2.inRange(hsv, np.array(low), np.array(high))
        
        # 改用闭运算（先膨胀后腐蚀），增强相邻区域合并
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)
        cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # 收集有效轮廓的边界框和面积
        boxes = []
        for c in cnts:
            area = cv2.contourArea(c)
            if area > min_area:
                x, y, w, h = cv2.boundingRect(c)
                # 转换为(x1, y1, x2, y2)格式用于NMS计算
                boxes.append((x, y, x + w, y + h, area, color))
        
        # 按面积降序排序（优先保留大面积框）
        boxes.sort(key=lambda b: b[4], reverse=True)
        nms_boxes = []
        
        # 非极大值抑制处理
        while boxes:
            current = boxes.pop(0)
            nms_boxes.append(current)
            remaining = []
            for box in boxes:
                # 计算当前框与候选框的交并比（IOU）
                x1, y1, x2, y2, _, _ = current
                x1b, y1b, x2b, y2b, _, _ = box
                # 计算交集区域
                inter_x1 = max(x1, x1b)
                inter_y1 = max(y1, y1b)
                inter_x2 = min(x2, x2b)
                inter_y2 = min(y2, y2b)
                inter_area = max(0, inter_x2 - inter_x1) * max(0, inter_y2 - inter_y1)
                # 计算并集区域
                current_area = (x2 - x1) * (y2 - y1)
                box_area = (x2b - x1b) * (y2b - y1b)
                union_area = current_area + box_area - inter_area
                # 计算IOU
                iou = inter_area / union_area if union_area != 0 else 0
                # 保留IOU小于阈值的框
                if iou < nms_threshold:
                    remaining.append(box)
            boxes = remaining
        
        # 转换回(x, y, w, h)格式并添加到检测结果
        for (x1, y1, x2, y2, _, color) in nms_boxes:
            detections.append((color, (x1, y1, x2 - x1, y2 - y1)))
    
    return detections

def draw_detections(frame, detections, draw_colors):
    for color, (x, y, w, h) in detections:
        cv2.rectangle(frame, (x, y), (x+w, y+h), draw_colors[color], 2)
        cv2.putText(frame, color, (x, y-10), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1.5, draw_colors[color], 2)
    return frame

def process_video(config_loader, mqtt_handler):
    color_ranges = config_loader.get_hsv_ranges()
    draw_colors = config_loader.get_draw_colors()
    min_area = config_loader.get_min_area()
    source = config_loader.get_video_source()

    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        logging.error("❌ 无法打开视频源")
        return

    # 创建两个窗口，分别显示原始检测结果和预处理后的图像
    cv2.namedWindow("LED Detection", cv2.WINDOW_NORMAL)
    cv2.resizeWindow("LED Detection", 1280, 720)
    cv2.namedWindow("Preprocessed Frame", cv2.WINDOW_NORMAL)
    cv2.resizeWindow("Preprocessed Frame", 1280, 720)

    try:
        while True:
            if config_loader.check_for_updates():
                new_color_ranges = config_loader.get_hsv_ranges()
                new_draw_colors = config_loader.get_draw_colors()
                new_min_area = config_loader.get_min_area()
                new_source = config_loader.get_video_source()
                mqtt_config = config_loader.get_mqtt_config()
                
                # 更新MQTT配置
                mqtt_handler.update_config(
                    broker=mqtt_config.get('broker'),
                    port=mqtt_config.get('port'),
                    topic=mqtt_config.get('topic'),
                    username=mqtt_config.get('user'),
                    password=mqtt_config.get('password'),
                    subscribe_topic=mqtt_config.get('subscribe_topic')
                )
                
                color_ranges = new_color_ranges
                draw_colors = new_draw_colors
                min_area = new_min_area
                
                if new_source != source:
                    source = new_source
                    cap.release()
                    cap = cv2.VideoCapture(source)
                    if not cap.isOpened():
                        logging.error("❌ 无法打开新的视频源")
                        break

            ret, frame = cap.read()
            if not ret:
                logging.warning("⚠️ 无法读取视频帧，重试...")
                time.sleep(0.5)
                continue

            # 应用高斯滤波预处理
            processed_frame = preprocess_frame(frame)

            if not mqtt_handler.connected:
                if not mqtt_handler.reconnect():
                    logging.error("❌ MQTT重连失败，退出程序")
                    break

            # 使用预处理后的帧进行检测
            detections = detect_leds(processed_frame, color_ranges, min_area)
            # 在原始帧上绘制检测结果
            frame_with_detections = draw_detections(frame.copy(), detections, draw_colors)

            counts = {color: 0 for color in color_ranges}
            for color, _ in detections:
                counts[color] += 1
            mqtt_handler.publish(json.dumps(counts))

            # 显示结果
            cv2.imshow("LED Detection", frame_with_detections)
            cv2.imshow("Preprocessed Frame", processed_frame)
            
            if cv2.waitKey(1) & 0xFF == 27:
                logging.info("🔍 用户请求退出")
                break

    finally:
        cap.release()
        cv2.destroyAllWindows()

def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.StreamHandler()]
    )
    
    config_loader = ConfigLoader()
    mqtt_config = config_loader.get_mqtt_config()
    
    # 初始化MQTT处理器
    mqtt_handler = MQTTHandler(
        broker=mqtt_config.get('broker'),
        port=mqtt_config.get('port'),
        topic=mqtt_config.get('topic'),
        username=mqtt_config.get('user'),
        password=mqtt_config.get('password'),
        subscribe_topic=mqtt_config.get('subscribe_topic')
    )
    # 关联配置加载器到MQTT处理器
    mqtt_handler.set_config_loader(config_loader)
    
    if not mqtt_handler.connect():
        logging.error("❌ 无法建立MQTT连接，程序退出")
        return
    
    process_video(config_loader, mqtt_handler)
    
    mqtt_handler.disconnect()
    logging.info("📌 程序已退出")

if __name__ == '__main__':
    main()
