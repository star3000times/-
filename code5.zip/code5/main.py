import cv2
import numpy as np
import math
import json
import logging
import time
import os
from config_loader import ConfigLoader
from mqtt_handler import MQTTHandler
#from video_processor import process_video  #普通后端
#from video_RTMP import process_video #上传服务器
from video_ffmpeg import process_video  #合并两个流

# MQTT主题
PUBLISH_TOPIC = "DCInspection/request/config/v6"    # 发布主题
SUBSCRIBE_TOPIC = "command/DCInspection/config/v6"  # 订阅主题

def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.StreamHandler()]
    )
    
    config_loader = ConfigLoader()
    mqtt_config = config_loader.get_mqtt_config()
    
    # 初始化MQTT处理器（使用固定主题）
    mqtt_handler = MQTTHandler(
        broker=mqtt_config.get('broker'),
        port=mqtt_config.get('port'),
        topic=PUBLISH_TOPIC,  # 固定发布主题
        username=mqtt_config.get('user'),
        password=mqtt_config.get('password'),
        subscribe_topic=SUBSCRIBE_TOPIC  # 固定订阅主题
    )
    mqtt_handler.set_config_loader(config_loader)
    
    if not mqtt_handler.connect():
        logging.error("❌ 无法建立MQTT连接，程序退出")
        return
    
    # 发送配置请求（使用固定发布主题）
    request_msg = json.dumps({"request": True})
    if mqtt_handler.publish(request_msg):
        logging.info(f"📤 已发送配置请求: {request_msg} 到主题 {PUBLISH_TOPIC}")
    else:
        logging.warning("⚠️ 配置请求发送失败")
    
    # 调用单独的视频处理函数
    process_video(config_loader, mqtt_handler)
    
    mqtt_handler.disconnect()
    logging.info("📌 程序已退出")

if __name__ == '__main__':
    main()
