现在连接的MQTT地址是提供了MQTT服务的ip地址
运行main1.py即可运行程序
输出的数据流如下：
{
    "code": "205",
    "mac":"54:b2:03:fd:76:0d",
    "device_no":"1660470864698724353",
    "device_type":"设备1",
    "device_name":"device1",
    "data1":220.4,
    "data2":"true",
    "data3":""led_counts": {"red": 1, "yellow": 1, "green": 1, "blue": 0}",
}
"data1":仪表数据
"data2":true或者false
"data3":"led_counts": {"red": 1, "yellow": 1, "green": 1, "blue": 0}
视频流地址：
![输出数据流介绍](1.png)
