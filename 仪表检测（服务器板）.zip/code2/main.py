import cv2
import numpy as np
import math
import json
import logging
import time
from config_loader import ConfigLoader
from mqtt_handler import MQTTHandler
import os 

# 圆位置平滑滤波器
class CircleSmoother:
    def __init__(self, buffer_size=5):
        self.buffer_size = buffer_size
        self.center_buffer = []
        self.radius_buffer = []
        self.last_detected = time.time()
    
    def update(self, center, radius):
        if center is not None:
            self.center_buffer.append(center)
            self.radius_buffer.append(radius)
            self.last_detected = time.time()
            
            # 保持缓冲区大小
            if len(self.center_buffer) > self.buffer_size:
                self.center_buffer.pop(0)
                self.radius_buffer.pop(0)
                
        # 超过1秒未检测到，清空缓冲区
        if time.time() - self.last_detected > 1.0:
            self.center_buffer = []
            self.radius_buffer = []
    
    def get_smooth_circle(self):
        if not self.center_buffer:
            return None, None
            
        avg_center = np.mean(self.center_buffer, axis=0)
        avg_radius = np.mean(self.radius_buffer)
        return avg_center.astype(int), int(avg_radius)

# 仪表检测核心函数
def detect_meter(frame, meter_params, circle_smoother, last_value):
    min_angle = meter_params["min_angle"]   # 量程最小角度（如-135度）
    max_angle = meter_params["max_angle"]   # 量程最大角度（如135度）
    min_value = meter_params["min_value"]   # 量程最小值（如0）
    max_value = meter_params["max_value"]   # 量程最大值（如6）
    angle_offset = meter_params.get("angle_offset", 0)  # 角度偏移量，默认0
    manual_angle = meter_params.get("manual_angle")  # 手动指针角度（优先使用）
    
    # 预处理
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (9, 9), 0)  # 更大的模糊核，减少噪声
    edges = cv2.Canny(blur, 30, 100)  # 调整边缘检测阈值
    
    reading = last_value  # 保持上一次读数，避免跳变
    height, width = gray.shape[:2]
    
    # 获取平滑后的圆位置，用于创建ROI
    smooth_center, smooth_radius = circle_smoother.get_smooth_circle()
    roi_x1, roi_y1, roi_x2, roi_y2 = 0, 0, width, height
    
    if smooth_center is not None and smooth_radius > 0:
        roi_size = int(smooth_radius * 2.5)
        roi_x1 = max(0, smooth_center[0] - roi_size)
        roi_y1 = max(0, smooth_center[1] - roi_size)
        roi_x2 = min(width, smooth_center[0] + roi_size)
        roi_y2 = min(height, smooth_center[1] + roi_size)
        roi = blur[roi_y1:roi_y2, roi_x1:roi_x2]
    else:
        roi = blur
    
    # 圆检测
    circles = cv2.HoughCircles(
        roi,
        cv2.HOUGH_GRADIENT,
        dp=1.2,  # 提高检测精度
        minDist=100,
        param1=50,
        param2=30,  # 提高置信度
        minRadius=80,
        maxRadius=200
    )
    
    circle_detected = False
    center_x, center_y, radius = None, None, None
    
    if circles is not None:
        circles = np.uint16(np.around(circles))
        if circles.shape[1] > 0:
            # 找到最佳圆（离中心最近的）
            best_circle = None
            min_dist = float('inf')
            
            for circle in circles[0, :]:
                cx, cy, cr = circle
                # 转换到原始坐标
                if smooth_center is not None:
                    cx += roi_x1
                    cy += roi_y1
                
                # 优先选择靠近图像中心的圆
                dist = math.sqrt((cx - width/2)**2 + (cy - height/2)** 2)
                
                if dist < min_dist:
                    min_dist = dist
                    best_circle = (cx, cy, cr)
            
            if best_circle:
                center_x, center_y, radius = best_circle
                circle_detected = True
                # 更新平滑器
                circle_smoother.update(np.array([center_x, center_y]), radius)
    
    # 使用平滑后的圆位置
    smooth_center, smooth_radius = circle_smoother.get_smooth_circle()
    if smooth_center is not None:
        center_x, center_y = smooth_center
        radius = smooth_radius
        circle_detected = True
    
    if circle_detected:
        # 绘制圆心和表盘
        cv2.circle(frame, (center_x, center_y), 5, (0, 0, 255), -1)
        cv2.circle(frame, (center_x, center_y), radius, (0, 255, 0), 2)
        
        mean_angle = None  # 最终使用的指针角度
        
        # 1. 尝试手动角度
        if manual_angle is not None:
            mean_angle = manual_angle
            logging.info(f"使用手动配置角度: {manual_angle}°")
        
        # 2. 直线检测
        else:
            # 创建ROI掩码，只在表盘内部检测指针
            roi_mask = np.zeros_like(gray)
            cv2.circle(roi_mask, (center_x, center_y), int(radius*0.85), 255, -1)
            roi_edges = cv2.bitwise_and(edges, roi_mask)
            
            # 霍夫线变换检测指针（优化参数）
            lines = cv2.HoughLinesP(
                roi_edges,
                rho=1,
                theta=np.pi/180,
                threshold=40,  # 提高阈值减少噪声
                minLineLength=radius*0.4,  # 指针最小长度
                maxLineGap=5  # 允许的线段间隙
            )
            
            if lines is not None:
                pointer_lines = []
                
                for line in lines:
                    x1, y1, x2, y2 = line[0]
                    # 计算线中点到圆心的距离
                    mid_x = (x1 + x2) / 2
                    mid_y = (y1 + y2) / 2
                    dist = math.sqrt((mid_x - center_x)**2 + (mid_y - center_y)** 2)
                    # 计算线长度
                    length = math.sqrt((x2-x1)**2 + (y2-y1)** 2)
                    
                    # 过滤条件：距圆心不远且长度合理
                    if dist < radius * 0.6 and length > radius*0.4 and length < radius*1.5:
                        # 判断是否通过圆心（角度差接近180度）
                        angle_to_center1 = math.degrees(math.atan2(center_y - y1, x1 - center_x))
                        angle_to_center2 = math.degrees(math.atan2(center_y - y2, x2 - center_x))
                        angle_diff = abs(angle_to_center1 - angle_to_center2)
                        
                        if angle_diff > 150:  # 角度差足够大，认为通过圆心
                            pointer_lines.append((x1, y1, x2, y2))
                
                if pointer_lines:
                    # 选择最长的线作为指针
                    longest_index = np.argmax([np.sqrt((l[2]-l[0])**2 + (l[3]-l[1])** 2) 
                                            for l in pointer_lines])
                    x1, y1, x2, y2 = pointer_lines[longest_index]
                    
                    # 确定指针端点：离圆心更远的点为尖端
                    dist1 = math.sqrt((x1-center_x)**2 + (y1-center_y)** 2)
                    dist2 = math.sqrt((x2-center_x)**2 + (y2-center_y)** 2)
                    
                    if dist1 > dist2:
                        pointer_tip = (x1, y1)
                    else:
                        pointer_tip = (x2, y2)
                    
                    # 计算指针角度（修正坐标系）
                    dx = pointer_tip[0] - center_x
                    dy = center_y - pointer_tip[1]  # 反转y轴，使向上为正
                    
                    angle_rad = math.atan2(dy, dx)
                    angle_deg = math.degrees(angle_rad)
                    
                    # 标准化角度到0-360度
                    if angle_deg < 0:
                        angle_deg += 360
                    
                    # 应用角度偏移
                    angle_deg = (angle_deg + angle_offset) % 360
                    
                    # 转换为仪表角度（0点在顶部）
                    meter_angle = 90 - angle_deg
                    if meter_angle < 0:
                        meter_angle += 360
                    
                    # 转换到[-180, 180]范围
                    if meter_angle > 180:
                        meter_angle -= 360
                    
                    mean_angle = meter_angle
                    logging.debug(f"自动检测角度: {mean_angle:.1f}°")
                else:
                    logging.warning("未检测到有效指针线段")
                    return frame, reading
        
        # 计算读数
        if mean_angle is not None:
            # 限制角度在量程范围内
            normalized_angle = max(min_angle, min(max_angle, mean_angle))
            
            # 映射角度到数值
            total_range_angle = max_angle - min_angle
            total_range_value = max_value - min_value
            if total_range_angle != 0 and total_range_value != 0:
                value = min_value + ((normalized_angle - min_angle) / total_range_angle) * total_range_value
                # 平滑处理（与main.py一致）
                reading = 0.8 * last_value + 0.2 * value
                logging.debug(f"计算读数: {reading:.2f}")
            
            # 修正后的代码
            arrow_length = radius * 0.8
            # 按照main.py的角度逻辑计算箭头方向，与指针尖端方向保持一致
            end_x = int(center_x + arrow_length * math.cos(math.radians(90 - mean_angle)))
            end_y = int(center_y - arrow_length * math.sin(math.radians(90 - mean_angle)))
            cv2.arrowedLine(frame, (center_x, center_y), (end_x, end_y), (0, 0, 255), 3)
        # 显示读数
        if reading is not None:
            # 半透明背景
            overlay = frame.copy()
            cv2.rectangle(overlay, (20, 20), (350, 100), (50, 50, 50), -1)
            frame = cv2.addWeighted(overlay, 0.6, frame, 0.4, 0)
            cv2.putText(
                frame,
                f"Reading: {reading:.2f}",
                (50, 70),
                cv2.FONT_HERSHEY_SIMPLEX,
                1.2,
                (0, 255, 255),
                2
            )
            cv2.putText(frame, f"Min: {min_value}", (50, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 200, 255), 2)
            cv2.putText(frame, f"Max: {max_value}", (200, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 200, 255), 2)
    
    else:
        logging.debug("未检测到表盘圆圈")
    
    return frame, reading

# 视频处理主循环
def process_video(config_loader, mqtt_handler):
    logging.info("⌛ 等待MQTT发送配置参数...")
    while True:
        if config_loader.mqtt_updated:
            video_source = config_loader.get_video_source()
            if video_source.isdigit() or (isinstance(video_source, str) and os.path.isfile(video_source)):
                logging.info("✅ 已收到MQTT配置，开始仪表检测流程")
                break
        if not mqtt_handler.connected:
            mqtt_handler.reconnect()
        time.sleep(1)
    
    # 初始化参数和圆平滑器
    meter_params = config_loader.get_meter_params()
    source = config_loader.get_video_source()
    output_path = config_loader.get_video_output()
    circle_smoother = CircleSmoother(buffer_size=10)  # 圆平滑器
    last_value = meter_params.get("min_value", 0)  # 初始读数
    
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        logging.error("❌ 无法打开视频源")
        return
    
    # 获取视频参数并初始化输出
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    # 尝试多种编解码器（与main.py一致）
    codecs = ['MJPG', 'XVID', 'DIVX', 'mp4v']
    out = None
    for codec in codecs:
        try:
            fourcc = cv2.VideoWriter_fourcc(*codec)
            out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
            if out.isOpened():
                logging.info(f"成功使用编解码器: {codec}")
                break
            else:
                out = None
        except:
            logging.warning(f"编解码器 {codec} 尝试失败")
    
    if out is None:
        logging.error("❌ 无法找到可用的视频编解码器!")
        return
    
    cv2.namedWindow("Meter Reading", cv2.WINDOW_NORMAL)
    
    try:
        while True:
            # 检查配置更新
            if config_loader.check_for_updates():
                new_meter_params = config_loader.get_meter_params()
                new_source = config_loader.get_video_source()
                new_output = config_loader.get_video_output()
                mqtt_config = config_loader.get_mqtt_config()
                
                # 更新MQTT配置
                mqtt_handler.update_config(
                    broker=mqtt_config.get('broker'),
                    port=mqtt_config.get('port'),
                    topic=mqtt_config.get('topic'),
                    username=mqtt_config.get('user'),
                    password=mqtt_config.get('password'),
                    subscribe_topic=mqtt_config.get('subscribe_topic')
                )
                
                meter_params = new_meter_params
                # 更新初始值
                last_value = meter_params.get("min_value", last_value)
                
                # 切换视频源
                if new_source != source:
                    source = new_source
                    cap.release()
                    cap = cv2.VideoCapture(source)
                    if not cap.isOpened():
                        logging.error("❌ 无法打开新视频源")
                        break
                
                # 切换输出路径
                if new_output != output_path:
                    output_path = new_output
                    out.release()
                    # 重新初始化输出
                    for codec in codecs:
                        try:
                            fourcc = cv2.VideoWriter_fourcc(*codec)
                            out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
                            if out.isOpened():
                                logging.info(f"切换到编解码器: {codec}")
                                break
                            else:
                                out = None
                        except:
                            continue
            
            ret, frame = cap.read()
            if not ret:
                logging.warning("⚠️ 无法读取视频帧，重试...")
                time.sleep(0.5)
                continue
            
            # 检测仪表并获取读数（传入圆平滑器和上一次读数）
            frame_with_result, reading = detect_meter(frame, meter_params, circle_smoother, last_value)
            last_value = reading  # 更新上一次读数
            
            # 发布结果到MQTT
            if reading is not None and mqtt_handler.connected:
                result = {"reading": round(reading, 2)}
                mqtt_handler.publish(json.dumps(result))
            
            # 写入输出视频
            out.write(frame_with_result)
            
            # 显示结果
            cv2.imshow("Meter Reading", frame_with_result)
            key = cv2.waitKey(1)
            if key == ord('q') or key == 27:  # ESC或Q退出
                logging.info("🔍 用户请求退出")
                break
            # 支持角度偏移调整（与main.py一致）
            elif key == ord('.') or key == ord('>'):
                meter_params["angle_offset"] = (meter_params.get("angle_offset", 0) + 5) % 360
                logging.info(f"角度偏移调整为: {meter_params['angle_offset']}°")
            elif key == ord(',') or key == ord('<'):
                meter_params["angle_offset"] = (meter_params.get("angle_offset", 0) - 5) % 360
                logging.info(f"角度偏移调整为: {meter_params['angle_offset']}°")
    
    finally:
        cap.release()
        out.release()
        cv2.destroyAllWindows()

# 主函数
def main():
    logging.basicConfig(
        level=logging.DEBUG,  
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.StreamHandler()]
    )
    
    config_loader = ConfigLoader()
    mqtt_config = config_loader.get_mqtt_config()
    
    mqtt_handler = MQTTHandler(
        broker=mqtt_config.get('broker'),
        port=mqtt_config.get('port'),
        topic=mqtt_config.get('topic'),
        username=mqtt_config.get('user'),
        password=mqtt_config.get('password'),
        subscribe_topic=mqtt_config.get('subscribe_topic')
    )
    mqtt_handler.set_config_loader(config_loader)
    
    if not mqtt_handler.connect():
        logging.error("❌ 无法建立MQTT连接，程序退出")
        return
    
    # 发送配置请求（包含角度偏移参数）
    request_msg = json.dumps({
        "request": True,
        "required_params": ["min_angle", "max_angle", "min_value", "max_value", "angle_offset"]
    })
    if mqtt_handler.publish(request_msg):
        logging.info(f"📤 已发送配置请求到主题 {mqtt_config.get('topic')}")
    else:
        logging.warning("⚠️ 配置请求发送失败")
    
    process_video(config_loader, mqtt_handler)
    mqtt_handler.disconnect()
    logging.info("📌 程序已退出")

if __name__ == '__main__':
    main()